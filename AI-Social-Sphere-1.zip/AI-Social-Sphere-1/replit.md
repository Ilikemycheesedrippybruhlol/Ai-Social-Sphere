# SocialAI - AI-Powered Social Media Platform

## Overview

SocialAI is a modern social media platform that integrates AI capabilities for content moderation and caption generation. Built as a full-stack web application, it features a React-based frontend with a clean, content-first design inspired by modern social platforms like Facebook and Instagram. The backend is powered by Express.js with PostgreSQL for data persistence.

The platform allows users to create posts with text and media (images/videos), interact through likes and comments, and leverage AI features for automatic caption generation and content moderation. The application emphasizes a streamlined user experience with real-time updates and responsive design.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server, providing fast HMR (Hot Module Replacement)
- **Wouter** for lightweight client-side routing (only home page and 404 currently implemented)
- **TanStack Query (React Query)** for server state management, data fetching, and caching

**UI Component System**
- **Radix UI** primitives for accessible, unstyled component foundations
- **shadcn/ui** component library built on Radix UI with customizable styling
- **Tailwind CSS** for utility-first styling with a custom design system
- **Custom theme system** supporting light/dark modes via ThemeProvider context

**Design System**
- Typography: Inter/Segoe UI for interface, System UI for post content
- Layout: Three-column desktop layout (left sidebar navigation, center feed, right sidebar insights/suggestions)
- Mobile-responsive with single-column stack and bottom navigation
- Spacing primitives based on Tailwind units (2, 3, 4, 6, 8)
- Custom color system with HSL-based theming for dynamic light/dark modes

**State Management**
- Server state: TanStack Query with custom query client configuration
- Local state: React hooks (useState, useContext)
- Global theme state: Context API via ThemeProvider
- Forms: React Hook Form with Zod validation (via @hookform/resolvers)

### Backend Architecture

**Server Framework**
- **Express.js** as the HTTP server framework
- **Node.js** runtime with ESM modules (type: "module")
- Custom middleware for JSON parsing, request logging, and error handling
- HTTP server created via Node's built-in `createServer` for potential WebSocket support

**API Design**
- RESTful API endpoints under `/api` prefix
- Current endpoints:
  - `GET /api/posts` - Retrieve all posts
  - `GET /api/posts/:id` - Retrieve single post
  - `POST /api/posts` - Create new post
  - `POST /api/comments/:id/like` - Like a comment
  - `POST /api/ai/caption` - Generate AI caption for image
- Request/response validation using Zod schemas
- Single demo user mode (DEMO_USER_ID constant)

**Data Layer**
- **Storage abstraction**: `IStorage` interface defining data operations
- **In-memory implementation**: `MemStorage` class for development/demo
- Designed for easy swap to database-backed storage (Drizzle ORM configuration present)
- Domain models: Users, Posts, Comments, Likes, CommentLikes

**Build & Deployment**
- **esbuild** for fast server-side bundling
- **tsx** for TypeScript execution in development
- Custom build script that bundles selected dependencies to reduce cold start times
- Static file serving for production client build
- Environment-based configuration (NODE_ENV)

### Database Schema (Configured but Not Active)

**ORM & Migration**
- **Drizzle ORM** configured with PostgreSQL dialect
- **drizzle-zod** for schema validation integration
- Migration files configured to output to `./migrations`
- Schema defined in `shared/schema.ts` for shared type safety

**Data Models**
- **users**: id, username, name, bio, profileImage
- **posts**: id, authorId, content, mediaUrl, mediaType, aiCaptioned, aiModerated, createdAt
- **comments**: id, postId, authorId, content, createdAt
- **likes**: id, postId, userId (for post likes)
- **commentLikes**: id, commentId, userId (for comment likes)

**Database Connection**
- PostgreSQL via environment variable `DATABASE_URL`
- Connection pooling via `pg` library
- Session store configured with `connect-pg-simple` (not currently active)

### External Dependencies

**AI Services**
- **OpenAI API** integration for:
  - Image caption generation (vision models)
  - Content moderation capabilities
- Conditional initialization based on `OPENAI_API_KEY` environment variable
- Returns null if API key not configured, allowing graceful degradation

**Third-Party Libraries**
- **date-fns**: Date formatting and manipulation
- **nanoid**: Unique ID generation for cache busting and entity IDs
- **uuid**: UUID generation (alternative ID strategy)
- **class-variance-authority**: Type-safe variant styling for components
- **clsx** & **tailwind-merge**: Conditional class name composition

**Development Tools**
- **Replit plugins**: Runtime error modal, cartographer, dev banner (development only)
- **TypeScript**: Full type checking with strict mode enabled
- Path aliases configured for clean imports (@/, @shared/, @assets/)

**Current Limitations**
- Single user mode (no authentication implemented)
- In-memory storage (data lost on restart)
- AI features require OpenAI API key configuration
- No file upload handling (media URLs only)
- No real-time features (WebSocket infrastructure present but unused)