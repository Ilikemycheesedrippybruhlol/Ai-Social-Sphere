# Design Guidelines: AI-Powered Social Media Platform

## Design Approach
**Reference-Based Design** drawing from modern social platforms:
- Primary inspiration: Facebook's current interface, Instagram's visual focus, Twitter's clean feed design
- Modern, content-first approach prioritizing user posts and visual media
- Streamlined UI that emphasizes user-generated content over chrome

## Typography System
**Font Families:**
- Primary: 'Inter' or 'Segoe UI' from Google Fonts for interface elements
- Post Content: 'System UI' for authentic, readable posts

**Hierarchy:**
- Navigation/Headers: text-base to text-lg, font-semibold
- Post Author Names: text-base, font-semibold
- Post Content: text-base, font-normal, leading-relaxed
- Timestamps/Meta: text-sm, font-normal
- Buttons/CTAs: text-sm to text-base, font-medium
- AI Labels/Badges: text-xs, font-medium, uppercase tracking-wide

## Layout System
**Spacing Primitives:** Use Tailwind units of 2, 3, 4, 6, and 8 consistently
- Component padding: p-4 to p-6
- Section spacing: space-y-4 to space-y-6
- Card gaps: gap-4
- Container margins: mx-auto with max-w-2xl for feed, max-w-7xl for full-width sections

**Grid Structure:**
- Main Feed: Single column, max-w-2xl centered for optimal reading
- Three-column desktop layout: Left sidebar (fixed navigation), Center feed (main content), Right sidebar (AI insights, suggestions)
- Mobile: Stack to single column, bottom navigation

## Component Library

### Navigation Bar (Top)
Fixed header with backdrop blur, shadow-sm
- Left: Logo with app name
- Center: Search bar (rounded-full, w-96 on desktop)
- Right: Icon buttons for Create Post, Notifications, Profile dropdown
- Height: h-16

### Post Creation Card
Prominent card at top of feed
- User avatar (w-10 h-10, rounded-full)
- Input placeholder: "What's on your mind?" (rounded-full, hover state)
- Media attachment buttons (Photo, Video, AI Caption)
- Expands to modal on click with full creation interface

### Feed Post Card
Elevated card with rounded-xl, shadow-sm
- Header: Avatar (w-12 h-12) + Name + Timestamp + Menu (3-dot)
- Post text content with proper line-height
- Media display: Full-width images/videos (aspect-video or aspect-square, rounded-lg)
- AI Badge: Small chip showing "AI Captioned" or "AI Moderated" with robot icon
- Engagement bar: Like, Comment, Share buttons (flex, space-x-4)
- Comments section: Nested with indentation, show 2-3 preview comments
- Bottom: Comment input with user avatar

### AI Integration Elements
**AI Caption Generator:**
- Floating badge on image upload showing "Generate Caption" button
- Loading state with shimmer animation
- Generated caption appears in textarea with edit capability

**Content Moderation Indicator:**
- Subtle badge on posts: "AI Verified" with checkmark
- Warning overlays for flagged content with explanation

**AI Insights Sidebar (Desktop Right):**
- "Trending Topics" card (AI-powered)
- "Suggested Friends" based on AI matching
- "Content Ideas" generator section

### Profile Page
Cover photo area (aspect-[3/1])
- Profile picture overlapping cover (-mt-16, w-32 h-32, ring-4 ring-white)
- Name, bio, stats row (Posts, Friends count)
- Edit profile button
- Tabs: Posts, Photos, Videos, About
- Grid layout for media (grid-cols-3 gap-1 on mobile, gap-2 on desktop)

### Modal Patterns
Post Creation Modal:
- Overlay with backdrop-blur
- Centered card (max-w-lg)
- Header with "Create Post" + Close button
- Textarea (min-h-32)
- Media preview area (grid for multiple uploads)
- AI tools panel: "Generate Caption", "Check Content"
- Action footer with Privacy dropdown + Post button

### Form Elements
- Inputs: rounded-lg, border, px-4 py-3
- Buttons: rounded-lg for primary actions, rounded-full for icon buttons
- Textareas: rounded-xl, min-h-24, resize-none
- Dropdowns: rounded-lg with chevron icon

## Icons
**Library:** Heroicons (outline for default, solid for active states)
- Navigation: Home, Search, Bell, User, Plus
- Post actions: Heart, ChatBubble, Share, Bookmark
- AI features: Sparkles (AI), CheckBadge (verified), ExclamationTriangle (warning)

## Images

### Hero/Authentication Page
Large split-screen layout for login/signup
- Left side (50%): Large hero image showcasing diverse people using the platform on devices, vibrant and welcoming, aspect-[4/3] object-cover
- Right side (50%): Authentication form with logo at top

### Post Content
- User-uploaded photos: Full-width within post card, max-h-96 object-cover, rounded-lg
- User-uploaded videos: aspect-video, controls visible, rounded-lg
- Profile pictures: Always circular (rounded-full)
- Cover photos: aspect-[3/1] on profiles

### Empty States
- Empty feed: Illustration of person with phone, encouraging first post
- No search results: Magnifying glass illustration with friendly message

## Animations
Minimal and purposeful only:
- Smooth transitions on hover states (transition-all duration-200)
- Like button: Scale animation on click (scale-110)
- Modal entry: Fade + scale (opacity and scale-95 to scale-100)
- Loading states: Subtle pulse on skeleton screens
- NO scroll-based animations, NO complex page transitions

## Responsive Behavior
**Desktop (lg+):**
- Three-column layout with sidebars
- Feed max-w-2xl centered
- Modal dialogs max-w-lg to max-w-2xl

**Tablet (md):**
- Two-column: Main feed + one sidebar
- Collapsed navigation to icons only

**Mobile (base):**
- Single column, full-width cards with border-x-0
- Bottom navigation bar (fixed, h-16, items-center)
- Hamburger menu for additional options
- Reduced spacing (p-3 instead of p-4)

## Accessibility
- Focus states: ring-2 ring-offset-2 on all interactive elements
- Alt text required for all images
- ARIA labels on icon-only buttons
- Keyboard navigation throughout
- Color contrast minimum 4.5:1 for text
- Screen reader announcements for AI-generated content

## Key Design Principles
1. **Content-First:** User posts dominate, UI chrome is minimal
2. **Familiar Patterns:** Leverage established social media conventions
3. **AI Transparency:** Clearly label AI-generated or AI-moderated content
4. **Visual Hierarchy:** Use consistent spacing and typography to guide attention
5. **Mobile Optimization:** Touch-friendly targets (min 44px), thumb-reachable navigation