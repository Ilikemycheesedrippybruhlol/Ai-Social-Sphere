import { NavHeader } from "@/components/NavHeader";
import { LeftSidebar } from "@/components/LeftSidebar";
import { RightSidebar } from "@/components/RightSidebar";
import { Feed } from "@/components/Feed";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <NavHeader />
      <div className="flex">
        <LeftSidebar />
        <main className="flex-1 min-h-[calc(100vh-4rem)]">
          <Feed />
        </main>
        <RightSidebar />
      </div>
    </div>
  );
}
