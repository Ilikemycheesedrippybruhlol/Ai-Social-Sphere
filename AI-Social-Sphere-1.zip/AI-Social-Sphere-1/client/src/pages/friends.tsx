import { useQuery, useMutation } from "@tanstack/react-query";
import { NavHeader } from "@/components/NavHeader";
import { LeftSidebar } from "@/components/LeftSidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserAvatar } from "@/components/UserAvatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, UserPlus, UserCheck, UserX, Users } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { User, FriendshipWithDetails } from "@shared/schema";

export default function Friends() {
  const { data: suggestions, isLoading: suggestionsLoading } = useQuery<User[]>({
    queryKey: ["/api/friends/suggestions"],
  });

  const { data: requests, isLoading: requestsLoading } = useQuery<FriendshipWithDetails[]>({
    queryKey: ["/api/friends/requests"],
  });

  const { data: friends, isLoading: friendsLoading } = useQuery<FriendshipWithDetails[]>({
    queryKey: ["/api/friends"],
  });

  const sendRequestMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("POST", `/api/friends/request/${userId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/friends/suggestions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friends/requests"] });
    },
  });

  const acceptRequestMutation = useMutation({
    mutationFn: async (friendshipId: string) => {
      const res = await apiRequest("POST", `/api/friends/respond/${friendshipId}`, { accept: true });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friends/requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const rejectRequestMutation = useMutation({
    mutationFn: async (friendshipId: string) => {
      const res = await apiRequest("POST", `/api/friends/respond/${friendshipId}`, { accept: false });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/friends/requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const pendingRequests = requests?.filter(r => r.status === "pending") || [];

  return (
    <div className="min-h-screen bg-background">
      <NavHeader />
      <div className="flex">
        <LeftSidebar />
        <main className="flex-1 min-h-[calc(100vh-4rem)] p-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-2xl font-bold mb-6">Friends</h1>
            
            <Tabs defaultValue="suggestions">
              <TabsList>
                <TabsTrigger value="suggestions" data-testid="tab-suggestions">
                  Suggestions
                </TabsTrigger>
                <TabsTrigger value="requests" data-testid="tab-requests">
                  Requests {pendingRequests.length > 0 && `(${pendingRequests.length})`}
                </TabsTrigger>
                <TabsTrigger value="all" data-testid="tab-all-friends">
                  All Friends
                </TabsTrigger>
              </TabsList>

              <TabsContent value="suggestions" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <UserPlus className="h-5 w-5" />
                      People You May Know
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {suggestionsLoading ? (
                      <div className="flex justify-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                      </div>
                    ) : suggestions && suggestions.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {suggestions.map((user) => (
                          <Card key={user.id} data-testid={`suggestion-card-${user.id}`}>
                            <CardContent className="p-4 text-center">
                              <UserAvatar name={user.name} image={user.profileImage || undefined} size="lg" className="mx-auto mb-3" />
                              <h3 className="font-semibold">{user.name}</h3>
                              <p className="text-sm text-muted-foreground mb-3">{user.bio?.slice(0, 50) || "No bio"}</p>
                              <Button 
                                className="w-full" 
                                onClick={() => sendRequestMutation.mutate(user.id)}
                                disabled={sendRequestMutation.isPending}
                                data-testid={`button-add-${user.id}`}
                              >
                                <UserPlus className="h-4 w-4 mr-2" />
                                Add Friend
                              </Button>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-muted-foreground py-8">No suggestions available</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="requests" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      Friend Requests
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {requestsLoading ? (
                      <div className="flex justify-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                      </div>
                    ) : pendingRequests.length > 0 ? (
                      <div className="space-y-4">
                        {pendingRequests.map((request) => (
                          <div 
                            key={request.id} 
                            className="flex items-center gap-4 p-4 rounded-lg border"
                            data-testid={`request-card-${request.id}`}
                          >
                            <UserAvatar 
                              name={request.requester.name} 
                              image={request.requester.profileImage || undefined} 
                            />
                            <div className="flex-1">
                              <h3 className="font-semibold">{request.requester.name}</h3>
                              <p className="text-sm text-muted-foreground">
                                {request.requester.friendCount || 0} friends
                              </p>
                            </div>
                            <div className="flex gap-2">
                              <Button 
                                onClick={() => acceptRequestMutation.mutate(request.id)}
                                disabled={acceptRequestMutation.isPending}
                                data-testid={`button-accept-${request.id}`}
                              >
                                <UserCheck className="h-4 w-4 mr-2" />
                                Accept
                              </Button>
                              <Button 
                                variant="outline"
                                onClick={() => rejectRequestMutation.mutate(request.id)}
                                disabled={rejectRequestMutation.isPending}
                                data-testid={`button-reject-${request.id}`}
                              >
                                <UserX className="h-4 w-4 mr-2" />
                                Decline
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-muted-foreground py-8">No pending friend requests</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="all" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      Your Friends
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {friendsLoading ? (
                      <div className="flex justify-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                      </div>
                    ) : friends && friends.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {friends.map((friendship) => {
                          const friend = friendship.requester.id === "demo-user" 
                            ? friendship.addressee 
                            : friendship.requester;
                          return (
                            <Card key={friendship.id} data-testid={`friend-card-${friend.id}`}>
                              <CardContent className="p-4 text-center">
                                <UserAvatar name={friend.name} image={friend.profileImage || undefined} size="lg" className="mx-auto mb-3" />
                                <h3 className="font-semibold">{friend.name}</h3>
                                <p className="text-sm text-muted-foreground">{friend.location || "Location not set"}</p>
                              </CardContent>
                            </Card>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="text-center text-muted-foreground py-8">You haven't added any friends yet</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}
