import { useQuery } from "@tanstack/react-query";
import { NavHeader } from "@/components/NavHeader";
import { LeftSidebar } from "@/components/LeftSidebar";
import { RightSidebar } from "@/components/RightSidebar";
import { PostCard } from "@/components/PostCard";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Star } from "lucide-react";
import type { User } from "@shared/schema";

interface PostAuthor {
  name: string;
  profileImage: string | null;
}

interface CommentData {
  id: string;
  author: PostAuthor;
  content: string;
  createdAt: string;
  likes: number;
  isLiked: boolean;
}

interface PostData {
  id: string;
  authorId: string;
  author: PostAuthor;
  content: string;
  mediaUrl: string | null;
  mediaType: string | null;
  createdAt: string;
  likes: number;
  comments: CommentData[];
  isLiked: boolean;
  isSaved: boolean;
  isFavorited: boolean;
  isHidden: boolean;
  aiCaptioned: boolean;
  aiModerated: boolean;
}

export default function Favorites() {
  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/me"],
  });

  const { data: posts, isLoading } = useQuery<PostData[]>({
    queryKey: ["/api/favorite-posts"],
  });

  return (
    <div className="min-h-screen bg-background">
      <NavHeader />
      
      <div className="flex max-w-7xl mx-auto">
        <LeftSidebar currentUser={currentUser ? { name: currentUser.name, image: currentUser.profileImage || undefined } : undefined} />
        
        <main className="flex-1 py-4 px-4 max-w-2xl mx-auto">
          <div className="flex items-center gap-2 mb-6">
            <Star className="h-6 w-6 text-yellow-500" />
            <h1 className="text-2xl font-bold">Favorites</h1>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : !posts || posts.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Star className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h2 className="text-lg font-semibold mb-2">No favorites yet</h2>
                <p className="text-muted-foreground">
                  Posts you add to favorites will appear here.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-0">
              {posts.map((post) => (
                <PostCard
                  key={post.id}
                  post={{
                    id: post.id,
                    authorId: post.authorId,
                    author: {
                      name: post.author.name,
                      image: post.author.profileImage || undefined,
                    },
                    content: post.content,
                    mediaUrl: post.mediaUrl || undefined,
                    mediaType: post.mediaType as "image" | "video" | undefined,
                    timestamp: new Date(post.createdAt),
                    likes: post.likes,
                    comments: post.comments.map((c) => ({
                      id: c.id,
                      author: {
                        name: c.author.name,
                        image: c.author.profileImage || undefined,
                      },
                      content: c.content,
                      timestamp: new Date(c.createdAt),
                      likes: c.likes,
                      isLiked: c.isLiked,
                    })),
                    isLiked: post.isLiked,
                    isSaved: post.isSaved,
                    isFavorited: post.isFavorited,
                    isHidden: post.isHidden,
                    aiCaptioned: post.aiCaptioned,
                    aiModerated: post.aiModerated,
                  }}
                />
              ))}
            </div>
          )}
        </main>

        <RightSidebar />
      </div>
    </div>
  );
}
