import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { NavHeader } from "@/components/NavHeader";
import { PostCard } from "@/components/PostCard";
import { UserAvatar } from "@/components/UserAvatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Loader2, MapPin, Link as LinkIcon, Users, UserPlus, Settings, Camera } from "lucide-react";
import type { User } from "@shared/schema";

interface PostAuthor {
  name: string;
  profileImage: string | null;
}

interface CommentData {
  id: string;
  author: PostAuthor;
  content: string;
  createdAt: string;
  likes: number;
  isLiked: boolean;
}

interface PostWithDetails {
  id: string;
  authorId: string;
  author: PostAuthor;
  content: string;
  mediaUrl: string | null;
  mediaType: string | null;
  createdAt: string;
  likes: number;
  comments: CommentData[];
  isLiked: boolean;
  isSaved: boolean;
  aiCaptioned: boolean;
  aiModerated: boolean;
}

interface ProfileData {
  user: User;
  posts: PostWithDetails[];
  isFriend: boolean;
  friendRequestSent: boolean;
}

export default function Profile() {
  const { userId } = useParams<{ userId: string }>();
  const currentUserId = "demo-user";
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editForm, setEditForm] = useState({
    name: "",
    bio: "",
    location: "",
    website: "",
  });

  const { data, isLoading, error } = useQuery<ProfileData>({
    queryKey: ["/api/users", userId || currentUserId, "profile"],
    queryFn: async () => {
      const res = await fetch(`/api/users/${userId || currentUserId}/profile`);
      if (!res.ok) throw new Error("Failed to fetch profile");
      return res.json();
    },
  });

  const sendFriendRequestMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/friends/request/${userId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "profile"] });
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (formData: typeof editForm) => {
      const res = await apiRequest("PATCH", `/api/users/${currentUserId}`, formData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId || currentUserId, "profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      setShowEditDialog(false);
    },
  });

  const openEditDialog = () => {
    if (data?.user) {
      setEditForm({
        name: data.user.name || "",
        bio: data.user.bio || "",
        location: data.user.location || "",
        website: data.user.website || "",
      });
    }
    setShowEditDialog(true);
  };

  const handleSaveProfile = () => {
    updateProfileMutation.mutate(editForm);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <NavHeader />
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-background">
        <NavHeader />
        <div className="text-center py-16 text-muted-foreground">
          Failed to load profile. Please try again.
        </div>
      </div>
    );
  }

  const { user, posts, isFriend, friendRequestSent } = data;
  const isOwnProfile = !userId || userId === currentUserId;

  return (
    <div className="min-h-screen bg-background">
      <NavHeader />
      
      <div className="max-w-4xl mx-auto">
        <div className="relative">
          <div 
            className="h-48 sm:h-64 bg-gradient-to-br from-primary/30 to-primary/10 sm:rounded-b-lg"
            style={user.coverImage ? { 
              backgroundImage: `url(${user.coverImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            } : undefined}
            data-testid="profile-cover"
          >
            {isOwnProfile && (
              <Button 
                variant="secondary" 
                size="sm" 
                className="absolute bottom-3 right-3 gap-2"
                data-testid="button-edit-cover"
              >
                <Camera className="h-4 w-4" />
                <span className="hidden sm:inline">Edit Cover</span>
              </Button>
            )}
          </div>

          <div className="px-4 sm:px-6">
            <div className="relative flex flex-col sm:flex-row sm:items-end gap-4 -mt-16 sm:-mt-20">
              <div className="relative">
                <UserAvatar 
                  name={user.name} 
                  image={user.profileImage || undefined} 
                  size="xl" 
                  className="ring-4 ring-background"
                />
                {isOwnProfile && (
                  <Button 
                    variant="secondary" 
                    size="icon" 
                    className="absolute bottom-0 right-0 rounded-full"
                    data-testid="button-edit-avatar"
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                )}
              </div>

              <div className="flex-1 pb-2 sm:pb-4">
                <h1 className="text-2xl font-bold" data-testid="text-profile-name">{user.name}</h1>
                <p className="text-muted-foreground" data-testid="text-profile-username">@{user.username}</p>
              </div>

              <div className="pb-2 sm:pb-4">
                {isOwnProfile ? (
                  <Button variant="outline" className="gap-2" onClick={openEditDialog} data-testid="button-edit-profile">
                    <Settings className="h-4 w-4" />
                    Edit Profile
                  </Button>
                ) : isFriend ? (
                  <Button variant="secondary" data-testid="button-friends-status">
                    <Users className="h-4 w-4 mr-2" />
                    Friends
                  </Button>
                ) : friendRequestSent ? (
                  <Button variant="secondary" disabled data-testid="button-request-sent">
                    Request Sent
                  </Button>
                ) : (
                  <Button 
                    onClick={() => sendFriendRequestMutation.mutate()}
                    disabled={sendFriendRequestMutation.isPending}
                    data-testid="button-add-friend"
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Add Friend
                  </Button>
                )}
              </div>
            </div>

            <div className="mt-4 space-y-3">
              {user.bio && (
                <p className="text-base" data-testid="text-profile-bio">{user.bio}</p>
              )}
              
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                {user.location && (
                  <span className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span data-testid="text-profile-location">{user.location}</span>
                  </span>
                )}
                {user.website && (
                  <a 
                    href={user.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-primary hover:underline"
                  >
                    <LinkIcon className="h-4 w-4" />
                    <span data-testid="text-profile-website">{user.website}</span>
                  </a>
                )}
              </div>

              <div className="flex gap-6 text-sm">
                <button className="hover:underline" data-testid="button-friends-count">
                  <span className="font-semibold">{user.friendCount || 0}</span>
                  <span className="text-muted-foreground ml-1">Friends</span>
                </button>
                <button className="hover:underline" data-testid="button-followers-count">
                  <span className="font-semibold">{user.followerCount || 0}</span>
                  <span className="text-muted-foreground ml-1">Followers</span>
                </button>
                <div data-testid="text-posts-count">
                  <span className="font-semibold">{posts.length}</span>
                  <span className="text-muted-foreground ml-1">Posts</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 sm:px-6 mt-6">
          <Tabs defaultValue="posts">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="posts" data-testid="tab-posts">Posts</TabsTrigger>
              <TabsTrigger value="photos" data-testid="tab-photos">Photos</TabsTrigger>
              <TabsTrigger value="about" data-testid="tab-about">About</TabsTrigger>
            </TabsList>

            <TabsContent value="posts" className="mt-4">
              {posts.length === 0 ? (
                <Card>
                  <CardContent className="py-12 text-center text-muted-foreground">
                    No posts yet.
                  </CardContent>
                </Card>
              ) : (
                <div className="max-w-2xl">
                  {posts.map((post) => (
                    <PostCard 
                      key={post.id} 
                      post={{
                        id: post.id,
                        author: {
                          name: post.author.name,
                          image: post.author.profileImage || undefined,
                        },
                        content: post.content,
                        mediaUrl: post.mediaUrl || undefined,
                        mediaType: post.mediaType as "image" | "video" | undefined,
                        timestamp: new Date(post.createdAt),
                        likes: post.likes,
                        comments: post.comments.map(c => ({
                          id: c.id,
                          author: {
                            name: c.author.name,
                            image: c.author.profileImage || undefined,
                          },
                          content: c.content,
                          timestamp: new Date(c.createdAt),
                          likes: c.likes,
                          isLiked: c.isLiked,
                        })),
                        isLiked: post.isLiked,
                        isFavorited: (post as any).isFavorited,
                        isHidden: (post as any).isHidden,
                        aiCaptioned: post.aiCaptioned || false,
                        aiModerated: post.aiModerated || false,
                      }} 
                    />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="photos" className="mt-4">
              <Card>
                <CardContent className="py-12">
                  {posts.filter(p => p.mediaUrl && p.mediaType === "image").length === 0 ? (
                    <p className="text-center text-muted-foreground">No photos yet.</p>
                  ) : (
                    <div className="grid grid-cols-3 gap-2">
                      {posts
                        .filter(p => p.mediaUrl && p.mediaType === "image")
                        .map((post) => (
                          <img 
                            key={post.id}
                            src={post.mediaUrl!}
                            alt="Photo"
                            className="aspect-square object-cover rounded-md"
                            data-testid={`photo-${post.id}`}
                          />
                        ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="about" className="mt-4">
              <Card>
                <CardContent className="py-6 space-y-4">
                  <div>
                    <h3 className="font-semibold mb-1">Bio</h3>
                    <p className="text-muted-foreground">{user.bio || "No bio added yet."}</p>
                  </div>
                  {user.location && (
                    <div>
                      <h3 className="font-semibold mb-1">Location</h3>
                      <p className="text-muted-foreground">{user.location}</p>
                    </div>
                  )}
                  {user.website && (
                    <div>
                      <h3 className="font-semibold mb-1">Website</h3>
                      <a 
                        href={user.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        {user.website}
                      </a>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
            <DialogDescription>
              Update your profile information below.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                data-testid="input-edit-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={editForm.bio}
                onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                data-testid="input-edit-bio"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={editForm.location}
                onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                data-testid="input-edit-location"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                value={editForm.website}
                onChange={(e) => setEditForm({ ...editForm, website: e.target.value })}
                data-testid="input-edit-website"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSaveProfile}
              disabled={updateProfileMutation.isPending}
              data-testid="button-save-profile"
            >
              {updateProfileMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : null}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
