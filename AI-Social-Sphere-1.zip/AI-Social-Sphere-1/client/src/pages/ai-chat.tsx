import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { NavHeader } from "@/components/NavHeader";
import { LeftSidebar } from "@/components/LeftSidebar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Loader2, 
  Send, 
  Trash2, 
  Sparkles, 
  Lightbulb, 
  PenLine,
  MessageCircle,
  Zap,
  Brain
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { UserAvatar } from "@/components/UserAvatar";

interface ChatMessage {
  id: string;
  userId: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

const quickPrompts = [
  { icon: PenLine, label: "Write a post", prompt: "Help me write an engaging social media post about " },
  { icon: Lightbulb, label: "Get ideas", prompt: "Give me creative content ideas for my social media about " },
  { icon: Sparkles, label: "Improve writing", prompt: "Help me improve this text to make it more engaging: " },
  { icon: Zap, label: "Trending topics", prompt: "What are some trending topics I could post about today?" },
];

export default function AIChat() {
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/me"],
  });

  const { data: messages, isLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/messages"],
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", "/api/chat", { message: content });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages"] });
      setMessage("");
    },
  });

  const clearHistoryMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", "/api/chat/messages");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages"] });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!message.trim() || sendMessageMutation.isPending) return;
    sendMessageMutation.mutate(message);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleQuickPrompt = (prompt: string) => {
    setMessage(prompt);
  };

  return (
    <div className="min-h-screen bg-background">
      <NavHeader />
      
      <div className="flex max-w-7xl mx-auto">
        <LeftSidebar currentUser={currentUser ? { name: currentUser.name, image: currentUser.profileImage || undefined } : undefined} />
        
        <main className="flex-1 py-4 px-4 lg:px-6">
          <div className="max-w-3xl mx-auto">
            <Card className="h-[calc(100vh-8rem)] flex flex-col overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between gap-4 p-4 border-b bg-gradient-to-r from-primary/5 to-primary/10">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center">
                      <Brain className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-green-500 rounded-full border-2 border-background" />
                  </div>
                  <div>
                    <h1 className="font-semibold text-lg flex items-center gap-2" data-testid="text-chat-title">
                      Llama AI
                      <Badge variant="secondary" className="text-xs">
                        <Sparkles className="h-3 w-3 mr-1" />
                        Powered by AI
                      </Badge>
                    </h1>
                    <p className="text-sm text-muted-foreground">Your intelligent social media assistant</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => clearHistoryMutation.mutate()}
                  disabled={clearHistoryMutation.isPending || !messages?.length}
                  data-testid="button-clear-chat"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear
                </Button>
              </div>

              {/* Messages Area */}
              <ScrollArea className="flex-1 p-4">
                {isLoading ? (
                  <div className="flex justify-center items-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : !messages || messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center px-4">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-6">
                      <Brain className="h-10 w-10 text-primary" />
                    </div>
                    <h2 className="text-xl font-semibold mb-2" data-testid="text-welcome-title">
                      Hey there! I'm Llama AI
                    </h2>
                    <p className="text-muted-foreground max-w-md mb-8">
                      I can help you create engaging posts, brainstorm content ideas, improve your writing, and more. What would you like to do today?
                    </p>
                    
                    {/* Quick Prompts */}
                    <div className="grid grid-cols-2 gap-3 w-full max-w-md">
                      {quickPrompts.map((prompt, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          className="h-auto py-3 px-4 flex flex-col items-start gap-1 text-left"
                          onClick={() => handleQuickPrompt(prompt.prompt)}
                          data-testid={`button-quick-prompt-${index}`}
                        >
                          <prompt.icon className="h-4 w-4 text-primary" />
                          <span className="text-sm font-medium">{prompt.label}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
                        data-testid={`chat-message-${msg.id}`}
                      >
                        {msg.role === "assistant" ? (
                          <div className="flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center">
                            <Brain className="h-5 w-5 text-primary-foreground" />
                          </div>
                        ) : (
                          <UserAvatar 
                            name={currentUser?.name || "You"} 
                            image={currentUser?.profileImage || undefined}
                            size="sm"
                          />
                        )}
                        <div className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"} max-w-[75%]`}>
                          <div
                            className={`rounded-2xl px-4 py-2.5 ${
                              msg.role === "user"
                                ? "bg-primary text-primary-foreground rounded-tr-sm"
                                : "bg-muted rounded-tl-sm"
                            }`}
                          >
                            <p className="text-sm whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                          </div>
                          <span className={`text-xs mt-1 ${msg.role === "user" ? "text-muted-foreground" : "text-muted-foreground"}`}>
                            {formatDistanceToNow(new Date(msg.createdAt), { addSuffix: true })}
                          </span>
                        </div>
                      </div>
                    ))}
                    {sendMessageMutation.isPending && (
                      <div className="flex gap-3">
                        <div className="flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center">
                          <Brain className="h-5 w-5 text-primary-foreground" />
                        </div>
                        <div className="bg-muted rounded-2xl rounded-tl-sm px-4 py-3">
                          <div className="flex items-center gap-1">
                            <div className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                            <div className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                            <div className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>

              {/* Quick Actions (only show when there are messages) */}
              {messages && messages.length > 0 && (
                <div className="px-4 py-2 border-t bg-muted/30">
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    <span className="text-xs text-muted-foreground whitespace-nowrap">Quick actions:</span>
                    {quickPrompts.slice(0, 3).map((prompt, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs whitespace-nowrap"
                        onClick={() => handleQuickPrompt(prompt.prompt)}
                        data-testid={`button-action-${index}`}
                      >
                        <prompt.icon className="h-3 w-3 mr-1" />
                        {prompt.label}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input Area */}
              <div className="p-4 border-t bg-background">
                <div className="flex gap-2 items-end">
                  <div className="flex-1 relative">
                    <Textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="Ask Llama AI anything..."
                      className="resize-none min-h-[44px] max-h-32 pr-12 rounded-xl"
                      rows={1}
                      disabled={sendMessageMutation.isPending}
                      data-testid="input-chat-message"
                    />
                  </div>
                  <Button
                    size="icon"
                    onClick={handleSendMessage}
                    disabled={!message.trim() || sendMessageMutation.isPending}
                    className="h-11 w-11 rounded-xl"
                    data-testid="button-send-message"
                  >
                    {sendMessageMutation.isPending ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <Send className="h-5 w-5" />
                    )}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  <MessageCircle className="h-3 w-3 inline mr-1" />
                  Llama AI can help you write posts, get content ideas, and improve your social presence
                </p>
              </div>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
