import { useQuery } from "@tanstack/react-query";
import { NavHeader } from "@/components/NavHeader";
import { LeftSidebar } from "@/components/LeftSidebar";
import { PostCard } from "@/components/PostCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Bookmark } from "lucide-react";
import type { PostWithDetails } from "@shared/schema";

export default function Saved() {
  const { data: savedPosts, isLoading } = useQuery<PostWithDetails[]>({
    queryKey: ["/api/saved-posts"],
  });

  return (
    <div className="min-h-screen bg-background">
      <NavHeader />
      <div className="flex">
        <LeftSidebar />
        <main className="flex-1 min-h-[calc(100vh-4rem)] p-4">
          <div className="max-w-2xl mx-auto">
            <h1 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Bookmark className="h-6 w-6" />
              Saved Posts
            </h1>
            
            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : savedPosts && savedPosts.length > 0 ? (
              <div className="space-y-4">
                {savedPosts.map((post) => (
                  <PostCard 
                    key={post.id} 
                    post={{
                      id: post.id,
                      author: {
                        name: post.author.name,
                        image: post.author.profileImage || undefined,
                      },
                      content: post.content,
                      mediaUrl: post.mediaUrl || undefined,
                      mediaType: post.mediaType as "image" | "video" | undefined,
                      timestamp: new Date(post.createdAt),
                      likes: post.likes,
                      comments: post.comments.map(c => ({
                        id: c.id,
                        author: {
                          name: c.author.name,
                          image: c.author.profileImage || undefined,
                        },
                        content: c.content,
                        timestamp: new Date(c.createdAt),
                        likes: c.likes,
                        isLiked: c.isLiked,
                      })),
                      isLiked: post.isLiked,
                      isSaved: post.isSaved,
                      isFavorited: (post as any).isFavorited,
                      isHidden: (post as any).isHidden,
                      aiCaptioned: post.aiCaptioned || false,
                      aiModerated: post.aiModerated || false,
                    }} 
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Bookmark className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h2 className="text-xl font-semibold mb-2">No saved posts yet</h2>
                  <p className="text-muted-foreground">
                    When you save posts, they will appear here for easy access.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
