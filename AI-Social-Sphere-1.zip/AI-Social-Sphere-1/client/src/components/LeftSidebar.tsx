import { Link, useLocation } from "wouter";
import { UserAvatar } from "./UserAvatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Home,
  Users,
  Bookmark,
  Clock,
  Settings,
  HelpCircle,
  Star,
  Brain,
  TrendingUp,
  Bell,
  Calendar,
} from "lucide-react";

interface LeftSidebarProps {
  currentUser?: {
    name: string;
    image?: string;
  };
}

const mainMenuItems = [
  { icon: Home, label: "Home", href: "/", badge: null },
  { icon: Users, label: "Friends", href: "/friends", badge: "3" },
  { icon: Brain, label: "Llama AI", href: "/chat", badge: "New" },
  { icon: Bookmark, label: "Saved", href: "/saved", badge: null },
  { icon: Star, label: "Favorites", href: "/favorites", badge: null },
];

const exploreItems = [
  { icon: TrendingUp, label: "Trending", href: "/trending" },
  { icon: Calendar, label: "Events", href: "/events" },
  { icon: Clock, label: "Memories", href: "/memories" },
];

const bottomItems = [
  { icon: Bell, label: "Notifications", href: "/notifications" },
  { icon: Settings, label: "Settings", href: "/settings" },
  { icon: HelpCircle, label: "Help Center", href: "/help" },
];

export function LeftSidebar({ currentUser }: LeftSidebarProps) {
  const [location] = useLocation();
  const user = currentUser || { name: "Alex Johnson" };

  return (
    <aside className="w-64 hidden lg:flex flex-col p-4 space-y-4 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto">
      {/* Profile Card */}
      <Link href="/profile">
        <div
          className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-primary/5 to-primary/10 hover-elevate cursor-pointer"
          data-testid="button-sidebar-profile"
        >
          <UserAvatar name={user.name} image={user.image} size="lg" />
          <div className="text-left flex-1 min-w-0">
            <p className="font-semibold text-sm truncate">{user.name}</p>
            <p className="text-xs text-muted-foreground">View your profile</p>
          </div>
        </div>
      </Link>

      {/* Main Navigation */}
      <nav className="space-y-1">
        {mainMenuItems.map((item) => (
          <Link key={item.label} href={item.href}>
            <Button
              variant={location === item.href ? "secondary" : "ghost"}
              className="w-full justify-start gap-3"
              data-testid={`button-nav-${item.label.toLowerCase().replace(" ", "-")}`}
            >
              <item.icon className={`h-5 w-5 ${location === item.href ? "text-primary" : ""}`} />
              <span className="flex-1 text-left">{item.label}</span>
              {item.badge && (
                <Badge 
                  variant={item.badge === "New" ? "default" : "secondary"} 
                  className="text-xs px-1.5 py-0"
                >
                  {item.badge}
                </Badge>
              )}
            </Button>
          </Link>
        ))}
      </nav>

      {/* Explore Section */}
      <div>
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide px-3 mb-2">
          Explore
        </p>
        <nav className="space-y-1">
          {exploreItems.map((item) => (
            <Link key={item.label} href={item.href}>
              <Button
                variant={location === item.href ? "secondary" : "ghost"}
                className="w-full justify-start gap-3 text-muted-foreground"
                data-testid={`button-nav-${item.label.toLowerCase()}`}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </Button>
            </Link>
          ))}
        </nav>
      </div>

      <div className="flex-1" />

      {/* Bottom Items */}
      <div className="space-y-1 pt-4 border-t">
        {bottomItems.map((item) => (
          <Link key={item.label} href={item.href}>
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 text-muted-foreground"
              size="sm"
              data-testid={`button-nav-${item.label.toLowerCase().replace(" ", "-")}`}
            >
              <item.icon className="h-4 w-4" />
              <span className="text-sm">{item.label}</span>
            </Button>
          </Link>
        ))}
      </div>

      <p className="text-xs text-muted-foreground px-3 py-2">
        SocialAI © 2024 · Privacy · Terms
      </p>
    </aside>
  );
}
