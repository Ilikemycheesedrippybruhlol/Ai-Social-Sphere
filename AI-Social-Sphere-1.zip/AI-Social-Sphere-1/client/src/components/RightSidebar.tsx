import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { UserAvatar } from "./UserAvatar";
import { 
  Sparkles, 
  TrendingUp, 
  Users, 
  Lightbulb, 
  Send, 
  Loader2, 
  Brain,
  ArrowRight,
  RefreshCw
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User } from "@shared/schema";

interface AIMessage {
  role: "user" | "assistant";
  content: string;
}

const trendingTopics = [
  { tag: "#AIPhotography", posts: 1234, trend: "up" },
  { tag: "#NatureLovers", posts: 856, trend: "up" },
  { tag: "#TechNews", posts: 623, trend: "stable" },
  { tag: "#TravelDiaries", posts: 412, trend: "up" },
  { tag: "#FoodieLife", posts: 389, trend: "up" },
];

export function RightSidebar() {
  const [chatMessage, setChatMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<AIMessage[]>([]);

  const { data: suggestedFriends, isLoading: friendsLoading } = useQuery<User[]>({
    queryKey: ["/api/friends/suggestions"],
  });

  const { data: contentIdeas, isLoading: ideasLoading } = useQuery({
    queryKey: ["/api/ai/content-ideas"],
    queryFn: async () => {
      const res = await fetch("/api/ai/content-ideas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      return res.json();
    },
    staleTime: 1000 * 60 * 5,
  });

  const sendFriendRequestMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("POST", `/api/friends/request/${userId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/friends/suggestions"] });
    },
  });

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const res = await apiRequest("POST", "/api/ai/chat", { 
        message,
        context: chatHistory.slice(-4).map(m => `${m.role}: ${m.content}`).join("\n"),
      });
      return res.json();
    },
    onSuccess: (data) => {
      setChatHistory(prev => [...prev, { role: "assistant", content: data.response }]);
    },
  });

  const refreshIdeasMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/ai/content-ideas", {});
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/ai/content-ideas"], data);
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    setChatHistory(prev => [...prev, { role: "user", content: chatMessage }]);
    chatMutation.mutate(chatMessage);
    setChatMessage("");
  };

  const ideas = contentIdeas?.ideas || [
    "Share a photo from your recent adventure",
    "Tell us about your favorite hobby",
    "Post a throwback memory",
  ];

  return (
    <aside className="w-80 hidden xl:block space-y-4 p-4 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto">
      {/* Llama AI Quick Chat */}
      <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center">
                <Brain className="h-4 w-4 text-primary-foreground" />
              </div>
              <span>Llama AI</span>
            </div>
            <Badge variant="secondary" className="text-xs">
              <Sparkles className="h-3 w-3 mr-1" />
              Online
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <ScrollArea className="h-32 rounded-md bg-background/50 p-2">
            {chatHistory.length === 0 ? (
              <div className="text-center text-sm text-muted-foreground py-4">
                <Brain className="h-8 w-8 mx-auto mb-2 opacity-40" />
                <p className="text-xs">Quick chat with Llama AI</p>
              </div>
            ) : (
              <div className="space-y-2">
                {chatHistory.map((msg, index) => (
                  <div
                    key={index}
                    className={`text-xs p-2 rounded-lg ${
                      msg.role === "user" 
                        ? "bg-primary text-primary-foreground ml-4" 
                        : "bg-muted mr-4"
                    }`}
                  >
                    {msg.content}
                  </div>
                ))}
                {chatMutation.isPending && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground p-2">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Thinking...
                  </div>
                )}
              </div>
            )}
          </ScrollArea>
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              placeholder="Ask anything..."
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              className="flex-1 h-9 text-sm bg-background"
              data-testid="input-ai-chat"
            />
            <Button 
              type="submit" 
              size="icon"
              className="h-9 w-9"
              disabled={!chatMessage.trim() || chatMutation.isPending}
              data-testid="button-send-ai-chat"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
          <Link href="/chat">
            <Button variant="ghost" size="sm" className="w-full text-xs">
              Open full chat
              <ArrowRight className="h-3 w-3 ml-1" />
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Trending Topics */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            Trending Now
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-1">
          {trendingTopics.map((topic, index) => (
            <button
              key={topic.tag}
              className="flex items-center justify-between w-full text-left hover-elevate rounded-lg p-2 -mx-2"
              data-testid={`button-trending-${topic.tag}`}
            >
              <div className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground w-4">{index + 1}</span>
                <div>
                  <span className="font-medium text-sm block">{topic.tag}</span>
                  <span className="text-xs text-muted-foreground">{topic.posts.toLocaleString()} posts</span>
                </div>
              </div>
            </button>
          ))}
        </CardContent>
      </Card>

      {/* Who to Follow */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            Who to Follow
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {friendsLoading ? (
            <div className="flex justify-center py-4">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : suggestedFriends?.slice(0, 3).map((friend) => (
            <div
              key={friend.id}
              className="flex items-center gap-3"
              data-testid={`suggested-friend-${friend.id}`}
            >
              <UserAvatar name={friend.name} image={friend.profileImage || undefined} size="sm" />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{friend.name}</p>
                <p className="text-xs text-muted-foreground truncate">@{friend.username}</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => sendFriendRequestMutation.mutate(friend.id)}
                disabled={sendFriendRequestMutation.isPending}
                data-testid={`button-follow-${friend.id}`}
              >
                Follow
              </Button>
            </div>
          ))}
          <Button variant="ghost" size="sm" className="w-full text-xs text-muted-foreground">
            Show more
          </Button>
        </CardContent>
      </Card>

      {/* Content Ideas */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lightbulb className="h-4 w-4 text-primary" />
              Post Ideas
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => refreshIdeasMutation.mutate()}
              disabled={refreshIdeasMutation.isPending}
              data-testid="button-refresh-ideas"
            >
              <RefreshCw className={`h-3 w-3 ${refreshIdeasMutation.isPending ? "animate-spin" : ""}`} />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {ideasLoading ? (
            <div className="flex justify-center py-4">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : (
            ideas.slice(0, 3).map((idea: string, index: number) => (
              <div
                key={index}
                className="p-2 text-sm bg-muted/50 rounded-lg hover-elevate cursor-pointer"
                data-testid={`content-idea-${index}`}
              >
                <Sparkles className="h-3 w-3 inline mr-2 text-primary" />
                {idea.replace(/^\d+\.\s*/, "")}
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="text-xs text-muted-foreground px-2 space-y-1">
        <div className="flex flex-wrap gap-x-2 gap-y-1">
          <a href="#" className="hover:underline">Terms of Service</a>
          <a href="#" className="hover:underline">Privacy Policy</a>
          <a href="#" className="hover:underline">Cookie Policy</a>
        </div>
        <p>SocialAI © 2024</p>
      </div>
    </aside>
  );
}
