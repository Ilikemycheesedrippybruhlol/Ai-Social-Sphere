import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { UserAvatar } from "./UserAvatar";
import { Send, Sparkles, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";

export interface Comment {
  id: string;
  author: {
    name: string;
    image?: string;
  };
  content: string;
  timestamp: Date;
  likes: number;
  isLiked?: boolean;
}

interface CommentSectionProps {
  postId: string;
  postContent?: string;
  comments: Comment[];
  onAddComment?: (content: string) => void;
  showAll?: boolean;
  currentUser?: {
    name: string;
    image?: string;
  };
}

export function CommentSection({
  postId,
  postContent,
  comments,
  onAddComment,
  showAll = false,
  currentUser,
}: CommentSectionProps) {
  const [newComment, setNewComment] = useState("");
  const [expanded, setExpanded] = useState(showAll);
  const [showSmartReplies, setShowSmartReplies] = useState(true);

  const user = currentUser || { name: "Alex Johnson" };
  const displayedComments = expanded ? comments : comments.slice(0, 2);

  const smartRepliesMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/ai/smart-replies", {
        postContent: postContent || "",
        commentContext: comments.slice(-3).map(c => c.content).join(", "),
      });
      return res.json();
    },
  });

  useEffect(() => {
    if (postContent && showSmartReplies) {
      smartRepliesMutation.mutate();
    }
  }, [postId]);

  const likeCommentMutation = useMutation({
    mutationFn: async (commentId: string) => {
      const res = await apiRequest("POST", `/api/comments/${commentId}/like`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    
    onAddComment?.(newComment);
    setNewComment("");
    setShowSmartReplies(false);
  };

  const handleSmartReply = (suggestion: string) => {
    const cleanSuggestion = suggestion.replace(/^[\d]+\.\s*/, "").replace(/^["']|["']$/g, "");
    setNewComment(cleanSuggestion);
    setShowSmartReplies(false);
  };

  const handleLike = (commentId: string) => {
    likeCommentMutation.mutate(commentId);
  };

  const smartReplies = smartRepliesMutation.data?.suggestions || [];

  return (
    <div className="space-y-3">
      {comments.length > 2 && !expanded && (
        <button
          onClick={() => setExpanded(true)}
          className="text-sm text-muted-foreground hover:underline"
          data-testid="button-view-more-comments"
        >
          View all {comments.length} comments
        </button>
      )}

      {displayedComments.map((comment) => (
        <div key={comment.id} className="flex gap-2" data-testid={`comment-${comment.id}`}>
          <UserAvatar name={comment.author.name} image={comment.author.image} size="sm" />
          <div className="flex-1">
            <div className="bg-muted rounded-xl px-3 py-2">
              <p className="font-semibold text-sm">{comment.author.name}</p>
              <p className="text-sm">{comment.content}</p>
            </div>
            <div className="flex items-center gap-3 mt-1 px-2">
              <button
                onClick={() => handleLike(comment.id)}
                className={`text-xs font-medium ${
                  comment.isLiked ? "text-destructive" : "text-muted-foreground hover:text-foreground"
                }`}
                data-testid={`button-like-comment-${comment.id}`}
              >
                Like {comment.likes > 0 && `(${comment.likes})`}
              </button>
              <span className="text-xs text-muted-foreground">
                {formatDistanceToNow(comment.timestamp, { addSuffix: true })}
              </span>
            </div>
          </div>
        </div>
      ))}

      {showSmartReplies && smartReplies.length > 0 && (
        <div className="flex flex-wrap gap-2 py-1">
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Sparkles className="h-3 w-3" />
            <span>AI suggestions:</span>
          </div>
          {smartReplies.map((suggestion: string, index: number) => (
            <Badge
              key={index}
              variant="secondary"
              className="cursor-pointer text-xs"
              onClick={() => handleSmartReply(suggestion)}
              data-testid={`smart-reply-${index}`}
            >
              {suggestion.replace(/^[\d]+\.\s*/, "").replace(/^["']|["']$/g, "").slice(0, 30)}
              {suggestion.length > 30 ? "..." : ""}
            </Badge>
          ))}
        </div>
      )}

      {smartRepliesMutation.isPending && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-3 w-3 animate-spin" />
          <span>Getting AI suggestions...</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <UserAvatar name={user.name} image={user.image} size="sm" />
        <div className="flex-1 relative">
          <Input
            placeholder="Write a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="rounded-full pr-10"
            data-testid="input-comment"
          />
          <Button
            type="submit"
            variant="ghost"
            size="icon"
            className="absolute right-1 top-1/2 -translate-y-1/2"
            disabled={!newComment.trim()}
            data-testid="button-submit-comment"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>
    </div>
  );
}
