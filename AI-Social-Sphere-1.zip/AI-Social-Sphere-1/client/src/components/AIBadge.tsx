import { Badge } from "@/components/ui/badge";
import { Sparkles, ShieldCheck, AlertTriangle } from "lucide-react";

interface AIBadgeProps {
  type: "captioned" | "moderated" | "warning";
  className?: string;
}

export function AIBadge({ type, className = "" }: AIBadgeProps) {
  const config = {
    captioned: {
      icon: Sparkles,
      label: "AI Captioned",
      variant: "secondary" as const,
    },
    moderated: {
      icon: ShieldCheck,
      label: "AI Verified",
      variant: "secondary" as const,
    },
    warning: {
      icon: AlertTriangle,
      label: "Content Warning",
      variant: "destructive" as const,
    },
  };

  const { icon: Icon, label, variant } = config[type];

  return (
    <Badge variant={variant} className={`text-xs gap-1 ${className}`}>
      <Icon className="w-3 h-3" />
      {label}
    </Badge>
  );
}
