import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserAvatar } from "./UserAvatar";
import { AIBadge } from "./AIBadge";
import { CommentSection, type Comment } from "./CommentSection";
import {
  Heart,
  MessageCircle,
  Bookmark,
  MoreHorizontal,
  ThumbsUp,
  Laugh,
  Frown,
  Pencil,
  Trash2,
  History,
  EyeOff,
  Star,
  Repeat2,
  Globe,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { formatDistanceToNow } from "date-fns";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { ReactionType } from "@shared/schema";

const reactionConfig: Record<ReactionType, { icon: typeof Heart; label: string; color: string }> = {
  like: { icon: ThumbsUp, label: "Like", color: "text-blue-500" },
  love: { icon: Heart, label: "Love", color: "text-red-500" },
  haha: { icon: Laugh, label: "Haha", color: "text-yellow-500" },
  wow: { icon: Laugh, label: "Wow", color: "text-yellow-500" },
  sad: { icon: Frown, label: "Sad", color: "text-yellow-500" },
  angry: { icon: Frown, label: "Angry", color: "text-orange-500" },
};

export interface ReactionSummary {
  type: ReactionType;
  count: number;
}

export interface OriginalPost {
  id: string;
  author: {
    name: string;
    image?: string;
  };
  content: string;
  mediaUrl?: string;
  mediaType?: "image" | "video";
  timestamp: Date;
}

export interface Post {
  id: string;
  authorId?: string;
  author: {
    name: string;
    image?: string;
    username?: string;
  };
  content: string;
  mediaUrl?: string;
  mediaType?: "image" | "video";
  timestamp: Date;
  likes: number;
  comments: Comment[];
  isLiked?: boolean;
  isSaved?: boolean;
  isFavorited?: boolean;
  isHidden?: boolean;
  aiCaptioned?: boolean;
  aiModerated?: boolean;
  reactions?: ReactionSummary[];
  userReaction?: ReactionType | null;
  isEdited?: boolean;
  editedAt?: Date;
  originalPostId?: string;
  originalPost?: OriginalPost;
  shareCount?: number;
}

interface PostCardProps {
  post: Post;
  currentUserId?: string;
}

export function PostCard({ post, currentUserId = "demo-user" }: PostCardProps) {
  const [isSaved, setIsSaved] = useState(post.isSaved || false);
  const [showComments, setShowComments] = useState(false);
  const [showReactionPicker, setShowReactionPicker] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [editContent, setEditContent] = useState(post.content);
  const [shareText, setShareText] = useState("");

  const isOwnPost = post.authorId === currentUserId;

  const reactionMutation = useMutation({
    mutationFn: async (type: ReactionType) => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/react`, { type });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const removeReactionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/posts/${post.id}/react`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const addCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/comments`, { content });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const editMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("PATCH", `/api/posts/${post.id}`, { content });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setShowEditDialog(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/posts/${post.id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setShowDeleteDialog(false);
    },
  });

  const shareMutation = useMutation({
    mutationFn: async (shareText: string) => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/share`, { shareText });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setShowShareDialog(false);
      setShareText("");
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/save`);
      return res.json();
    },
    onSuccess: (data) => {
      setIsSaved(data.saved);
      queryClient.invalidateQueries({ queryKey: ["/api/saved-posts"] });
    },
  });

  const hideMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/hide`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/hidden-posts"] });
    },
  });

  const favoriteMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/favorite`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorite-posts"] });
    },
  });

  const handleReaction = (type: ReactionType) => {
    if (post.userReaction === type) {
      removeReactionMutation.mutate();
    } else {
      reactionMutation.mutate(type);
    }
    setShowReactionPicker(false);
  };

  const handleSave = () => {
    saveMutation.mutate();
  };

  const handleShare = () => {
    setShowShareDialog(true);
  };

  const handleAddComment = (content: string) => {
    addCommentMutation.mutate(content);
  };

  const handleEdit = () => {
    editMutation.mutate(editContent);
  };

  const handleDelete = () => {
    deleteMutation.mutate();
  };

  const handleShareSubmit = () => {
    shareMutation.mutate(shareText);
  };

  const totalReactions = post.reactions?.reduce((sum, r) => sum + r.count, 0) || post.likes || 0;
  const topReactions = post.reactions?.filter(r => r.count > 0).slice(0, 3) || [];
  const userReactionConfig = post.userReaction ? reactionConfig[post.userReaction] : null;

  return (
    <>
      <Card className="mb-4" data-testid={`post-card-${post.id}`}>
        <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 pb-3">
          <div className="flex items-start gap-3">
            <Link href={`/profile/${post.authorId || 'demo-user'}`}>
              <UserAvatar name={post.author.name} image={post.author.image} size="lg" className="cursor-pointer" />
            </Link>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <Link href={`/profile/${post.authorId || 'demo-user'}`}>
                  <span className="font-semibold hover:underline cursor-pointer" data-testid={`text-author-${post.id}`}>
                    {post.author.name}
                  </span>
                </Link>
                {post.author.username && (
                  <span className="text-muted-foreground text-sm">@{post.author.username}</span>
                )}
                <span className="text-muted-foreground text-sm">·</span>
                <span className="text-muted-foreground text-sm">
                  {formatDistanceToNow(post.timestamp, { addSuffix: false })}
                </span>
                {post.isEdited && (
                  <span className="text-xs text-muted-foreground flex items-center gap-1" data-testid={`text-edited-${post.id}`}>
                    · <History className="h-3 w-3" />
                    edited
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                <Globe className="h-3 w-3" />
                <span>Public</span>
              </div>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" data-testid={`button-post-menu-${post.id}`}>
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {isOwnPost && (
                <>
                  <DropdownMenuItem 
                    onClick={() => {
                      setEditContent(post.content);
                      setShowEditDialog(true);
                    }}
                    data-testid={`button-edit-${post.id}`}
                  >
                    <Pencil className="h-4 w-4 mr-2" />
                    Edit Post
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={() => setShowDeleteDialog(true)}
                    className="text-destructive"
                    data-testid={`button-delete-${post.id}`}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete Post
                  </DropdownMenuItem>
                </>
              )}
              <DropdownMenuItem
                onClick={() => favoriteMutation.mutate()}
                data-testid={`button-favorite-${post.id}`}
              >
                <Star className={`h-4 w-4 mr-2 ${post.isFavorited ? "fill-yellow-500 text-yellow-500" : ""}`} />
                {post.isFavorited ? "Remove from Favorites" : "Add to Favorites"}
              </DropdownMenuItem>
              {!isOwnPost && (
                <DropdownMenuItem
                  onClick={() => hideMutation.mutate()}
                  data-testid={`button-hide-${post.id}`}
                >
                  <EyeOff className="h-4 w-4 mr-2" />
                  {post.isHidden ? "Unhide Post" : "Hide Post"}
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </CardHeader>

        <CardContent className="pb-3">
          <p className="text-base leading-relaxed mb-3" data-testid={`text-content-${post.id}`}>
            {post.content}
          </p>

          {post.originalPost && (
            <Card className="bg-muted/50 mb-3" data-testid={`shared-post-${post.id}`}>
              <CardHeader className="pb-2 pt-3">
                <div className="flex items-center gap-2">
                  <UserAvatar name={post.originalPost.author.name} image={post.originalPost.author.image} size="sm" />
                  <div>
                    <p className="text-sm font-medium">{post.originalPost.author.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(post.originalPost.timestamp), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-3 pt-0">
                <p className="text-sm">{post.originalPost.content}</p>
                {post.originalPost.mediaUrl && (
                  <div className="mt-2 rounded-md overflow-hidden">
                    {post.originalPost.mediaType === "video" ? (
                      <video src={post.originalPost.mediaUrl} controls className="w-full max-h-48 object-cover" />
                    ) : (
                      <img src={post.originalPost.mediaUrl} alt="Shared post media" className="w-full max-h-48 object-cover" />
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {post.mediaUrl && !post.originalPost && (
            <div className="relative -mx-6 mb-3">
              {post.mediaType === "video" ? (
                <video
                  src={post.mediaUrl}
                  controls
                  className="w-full aspect-video object-cover"
                  data-testid={`video-${post.id}`}
                />
              ) : (
                <img
                  src={post.mediaUrl}
                  alt="Post media"
                  className="w-full max-h-96 object-cover"
                  data-testid={`image-${post.id}`}
                />
              )}
              <div className="absolute top-2 left-2 flex gap-1">
                {post.aiCaptioned && <AIBadge type="captioned" />}
                {post.aiModerated && <AIBadge type="moderated" />}
              </div>
            </div>
          )}

          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              {totalReactions > 0 && (
                <>
                  <div className="flex -space-x-1">
                    {topReactions.length > 0 ? (
                      topReactions.map((reaction) => {
                        const config = reactionConfig[reaction.type];
                        const Icon = config.icon;
                        return (
                          <div 
                            key={reaction.type} 
                            className={`h-5 w-5 rounded-full bg-background flex items-center justify-center ${config.color}`}
                          >
                            <Icon className="h-3 w-3 fill-current" />
                          </div>
                        );
                      })
                    ) : (
                      <Heart className="h-4 w-4 fill-destructive text-destructive" />
                    )}
                  </div>
                  <span data-testid={`text-reactions-${post.id}`} className="ml-1">{totalReactions}</span>
                </>
              )}
            </div>
            <div className="flex items-center gap-3">
              {(post.shareCount ?? 0) > 0 && (
                <span data-testid={`text-shares-${post.id}`}>{post.shareCount} share{post.shareCount !== 1 ? "s" : ""}</span>
              )}
              {post.comments.length > 0 && (
                <button
                  onClick={() => setShowComments(!showComments)}
                  className="hover:underline"
                  data-testid={`button-view-comments-${post.id}`}
                >
                  {post.comments.length} comment{post.comments.length !== 1 ? "s" : ""}
                </button>
              )}
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex flex-col gap-3 pt-0">
          <div className="flex items-center w-full border-t pt-3 -mt-1">
            <Popover open={showReactionPicker} onOpenChange={setShowReactionPicker}>
              <PopoverTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`flex-1 gap-2 ${userReactionConfig ? userReactionConfig.color : "text-muted-foreground"}`}
                  data-testid={`button-react-${post.id}`}
                >
                  {userReactionConfig ? (
                    <>
                      <userReactionConfig.icon className="h-[18px] w-[18px] fill-current" />
                      <span className="hidden sm:inline">{userReactionConfig.label}</span>
                    </>
                  ) : (
                    <>
                      <Heart className="h-[18px] w-[18px]" />
                      <span className="hidden sm:inline">Like</span>
                    </>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-2" side="top" align="start">
                <div className="flex gap-1">
                  {(Object.entries(reactionConfig) as [ReactionType, typeof reactionConfig.like][]).map(([type, config]) => {
                    const Icon = config.icon;
                    const isActive = post.userReaction === type;
                    return (
                      <button
                        key={type}
                        onClick={() => handleReaction(type)}
                        className={`p-2 rounded-full hover-elevate transition-transform hover:scale-110 ${isActive ? 'bg-muted' : ''}`}
                        data-testid={`button-reaction-${type}-${post.id}`}
                        title={config.label}
                      >
                        <Icon className={`h-6 w-6 ${config.color} ${isActive ? 'fill-current' : ''}`} />
                      </button>
                    );
                  })}
                </div>
              </PopoverContent>
            </Popover>
            <Button
              variant="ghost"
              size="sm"
              className="flex-1 gap-2 text-muted-foreground"
              onClick={() => setShowComments(!showComments)}
              data-testid={`button-comment-${post.id}`}
            >
              <MessageCircle className="h-[18px] w-[18px]" />
              <span className="hidden sm:inline">Comment</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex-1 gap-2 text-muted-foreground"
              onClick={handleShare}
              data-testid={`button-share-${post.id}`}
            >
              <Repeat2 className="h-[18px] w-[18px]" />
              <span className="hidden sm:inline">Share</span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={isSaved ? "text-primary" : "text-muted-foreground"}
              onClick={handleSave}
              disabled={saveMutation.isPending}
              data-testid={`button-save-${post.id}`}
            >
              <Bookmark className={`h-[18px] w-[18px] ${isSaved ? "fill-current" : ""}`} />
            </Button>
          </div>

          {showComments && (
            <div className="w-full">
              <CommentSection
                postId={post.id}
                postContent={post.content}
                comments={post.comments}
                onAddComment={handleAddComment}
              />
            </div>
          )}
        </CardFooter>
      </Card>

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Post</DialogTitle>
            <DialogDescription>
              Make changes to your post. Your original content will be saved in edit history.
            </DialogDescription>
          </DialogHeader>
          <Textarea
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            placeholder="What's on your mind?"
            className="min-h-[120px]"
            data-testid="input-edit-content"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleEdit} 
              disabled={editMutation.isPending || !editContent.trim()}
              data-testid="button-save-edit"
            >
              {editMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Post</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this post? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Post</DialogTitle>
            <DialogDescription>
              Share this post with your friends. Add your own thoughts (optional).
            </DialogDescription>
          </DialogHeader>
          <Textarea
            value={shareText}
            onChange={(e) => setShareText(e.target.value)}
            placeholder="Add your thoughts about this post..."
            className="min-h-[80px]"
            data-testid="input-share-text"
          />
          <Card className="bg-muted/50">
            <CardHeader className="pb-2 pt-3">
              <div className="flex items-center gap-2">
                <UserAvatar name={post.author.name} image={post.author.image} size="sm" />
                <div>
                  <p className="text-sm font-medium">{post.author.name}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pb-3 pt-0">
              <p className="text-sm text-muted-foreground line-clamp-3">{post.content}</p>
            </CardContent>
          </Card>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowShareDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleShareSubmit} 
              disabled={shareMutation.isPending}
              data-testid="button-confirm-share"
            >
              {shareMutation.isPending ? "Sharing..." : "Share Now"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
