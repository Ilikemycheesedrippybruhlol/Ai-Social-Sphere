import { CreatePostCard } from "../CreatePostCard";

export default function CreatePostCardExample() {
  return (
    <CreatePostCard
      onSubmit={(post) => console.log("Post created:", post)}
    />
  );
}
