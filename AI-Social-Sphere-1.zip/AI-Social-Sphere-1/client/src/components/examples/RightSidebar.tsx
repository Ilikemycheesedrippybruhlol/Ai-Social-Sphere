import { RightSidebar } from "../RightSidebar";

export default function RightSidebarExample() {
  return (
    <div className="bg-background min-h-screen">
      <RightSidebar />
    </div>
  );
}
