import { NavHeader } from "../NavHeader";
import { ThemeProvider } from "../ThemeProvider";

export default function NavHeaderExample() {
  return (
    <ThemeProvider>
      <NavHeader onCreatePost={() => console.log("Create post clicked")} />
    </ThemeProvider>
  );
}
