import { LeftSidebar } from "../LeftSidebar";

export default function LeftSidebarExample() {
  return (
    <div className="bg-background min-h-screen">
      <LeftSidebar />
    </div>
  );
}
