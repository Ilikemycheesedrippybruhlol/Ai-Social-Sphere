import { CommentSection, type Comment } from "../CommentSection";

// todo: remove mock data
const mockComments: Comment[] = [
  {
    id: "1",
    author: { name: "Sarah Miller" },
    content: "This is absolutely beautiful! Where was this taken?",
    timestamp: new Date(Date.now() - 3600000),
    likes: 5,
    isLiked: true,
  },
  {
    id: "2",
    author: { name: "Mike Chen" },
    content: "Amazing shot! The lighting is perfect.",
    timestamp: new Date(Date.now() - 7200000),
    likes: 2,
    isLiked: false,
  },
  {
    id: "3",
    author: { name: "Emily Davis" },
    content: "I need to visit this place!",
    timestamp: new Date(Date.now() - 10800000),
    likes: 1,
    isLiked: false,
  },
];

export default function CommentSectionExample() {
  return (
    <CommentSection
      comments={mockComments}
      onAddComment={(content) => console.log("Comment added:", content)}
      onLikeComment={(id) => console.log("Comment liked:", id)}
    />
  );
}
