import { AIBadge } from "../AIBadge";

export default function AIBadgeExample() {
  return (
    <div className="flex flex-wrap gap-2">
      <AIBadge type="captioned" />
      <AIBadge type="moderated" />
      <AIBadge type="warning" />
    </div>
  );
}
