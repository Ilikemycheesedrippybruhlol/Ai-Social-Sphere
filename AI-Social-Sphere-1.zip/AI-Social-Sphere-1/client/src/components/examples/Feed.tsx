import { Feed } from "../Feed";

export default function FeedExample() {
  return <Feed />;
}
