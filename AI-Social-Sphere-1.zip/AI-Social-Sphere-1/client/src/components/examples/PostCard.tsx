import { PostCard, type Post } from "../PostCard";

// todo: remove mock data
const mockPost: Post = {
  id: "1",
  author: {
    name: "Jessica Williams",
  },
  content: "Just captured this incredible sunset during my evening hike! Nature never fails to amaze me. The colors were absolutely breathtaking today.",
  mediaUrl: "https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=800",
  mediaType: "image",
  timestamp: new Date(Date.now() - 3600000 * 2),
  likes: 42,
  comments: [
    {
      id: "c1",
      author: { name: "Sarah Miller" },
      content: "This is absolutely beautiful! Where was this taken?",
      timestamp: new Date(Date.now() - 3600000),
      likes: 5,
      isLiked: true,
    },
    {
      id: "c2",
      author: { name: "Mike Chen" },
      content: "Amazing shot! The lighting is perfect.",
      timestamp: new Date(Date.now() - 7200000),
      likes: 2,
      isLiked: false,
    },
  ],
  isLiked: true,
  aiCaptioned: true,
  aiModerated: true,
};

export default function PostCardExample() {
  return (
    <PostCard
      post={mockPost}
      onLike={(id) => console.log("Liked:", id)}
      onSave={(id) => console.log("Saved:", id)}
      onShare={(id) => console.log("Shared:", id)}
      onAddComment={(id, content) => console.log("Comment on", id, ":", content)}
    />
  );
}
