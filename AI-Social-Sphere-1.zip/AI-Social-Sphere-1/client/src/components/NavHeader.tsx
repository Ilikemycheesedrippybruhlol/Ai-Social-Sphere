import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "./ThemeToggle";
import { UserAvatar } from "./UserAvatar";
import {
  Home,
  Users,
  Bell,
  MessageCircle,
  Search,
  Plus,
  Menu,
  Sparkles,
  Heart,
  UserPlus,
  MessageSquare,
  CheckCheck,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDistanceToNow } from "date-fns";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { NotificationWithDetails } from "../../../server/storage";

interface NavHeaderProps {
  onCreatePost?: () => void;
  currentUser?: {
    name: string;
    image?: string;
  };
}

const notificationIcons: Record<string, typeof Heart> = {
  like: Heart,
  comment: MessageSquare,
  friend_request: UserPlus,
  friend_accept: Users,
  mention: MessageCircle,
  ai_suggestion: Sparkles,
};

export function NavHeader({ onCreatePost, currentUser }: NavHeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const user = currentUser || { name: "Alex Johnson" };

  const { data: notifications } = useQuery<NotificationWithDetails[]>({
    queryKey: ["/api/notifications"],
  });

  const { data: unreadCount } = useQuery<{ count: number }>({
    queryKey: ["/api/notifications/unread-count"],
  });

  const markReadMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      const res = await apiRequest("POST", `/api/notifications/${notificationId}/read`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
    },
  });

  const markAllReadMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/notifications/read-all");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
    },
  });

  const handleNotificationClick = (notification: NotificationWithDetails) => {
    if (!notification.read) {
      markReadMutation.mutate(notification.id);
    }
  };

  const getNotificationText = (notification: NotificationWithDetails) => {
    switch (notification.type) {
      case "like":
        return `${notification.actor?.name || "Someone"} liked your post`;
      case "comment":
        return `${notification.actor?.name || "Someone"} commented on your post`;
      case "friend_request":
        return `${notification.actor?.name || "Someone"} sent you a friend request`;
      case "friend_accept":
        return `${notification.actor?.name || "Someone"} accepted your friend request`;
      case "mention":
        return `${notification.actor?.name || "Someone"} mentioned you`;
      case "ai_suggestion":
        return notification.content || "AI has a suggestion for you";
      default:
        return notification.content || "New notification";
    }
  };

  return (
    <header className="sticky top-0 z-50 h-16 bg-background/95 backdrop-blur border-b flex items-center px-4 gap-4">
      <div className="flex items-center gap-2">
        <Link href="/">
          <div className="flex items-center gap-2 text-primary font-semibold text-lg cursor-pointer">
            <Sparkles className="h-6 w-6" />
            <span className="hidden sm:inline">SocialAI</span>
          </div>
        </Link>
      </div>

      <div className="flex-1 max-w-md mx-auto hidden md:block">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search posts, people..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 rounded-full bg-muted border-0"
            data-testid="input-search"
          />
        </div>
      </div>

      <nav className="flex items-center gap-1">
        <Link href="/">
          <Button variant="ghost" size="icon" data-testid="button-home">
            <Home className="h-5 w-5" />
          </Button>
        </Link>
        <Button variant="ghost" size="icon" data-testid="button-friends">
          <Users className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" data-testid="button-messages">
          <MessageCircle className="h-5 w-5" />
        </Button>

        <Popover open={notificationsOpen} onOpenChange={setNotificationsOpen}>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="relative" data-testid="button-notifications">
              <Bell className="h-5 w-5" />
              {(unreadCount?.count || 0) > 0 && (
                <span className="absolute -top-0.5 -right-0.5 h-4 w-4 bg-destructive rounded-full text-xs text-destructive-foreground flex items-center justify-center">
                  {unreadCount?.count}
                </span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-0" align="end">
            <div className="flex items-center justify-between p-3 border-b">
              <h3 className="font-semibold">Notifications</h3>
              {(unreadCount?.count || 0) > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="gap-1 text-xs"
                  onClick={() => markAllReadMutation.mutate()}
                  disabled={markAllReadMutation.isPending}
                  data-testid="button-mark-all-read"
                >
                  <CheckCheck className="h-3 w-3" />
                  Mark all read
                </Button>
              )}
            </div>
            <ScrollArea className="h-80">
              {notifications && notifications.length > 0 ? (
                <div>
                  {notifications.map((notification) => {
                    const Icon = notificationIcons[notification.type] || Bell;
                    return (
                      <button
                        key={notification.id}
                        className={`w-full flex items-start gap-3 p-3 text-left hover-elevate ${!notification.read ? 'bg-muted/50' : ''}`}
                        onClick={() => handleNotificationClick(notification)}
                        data-testid={`notification-${notification.id}`}
                      >
                        <div className="shrink-0">
                          {notification.actor ? (
                            <UserAvatar 
                              name={notification.actor.name} 
                              image={notification.actor.profileImage || undefined}
                              size="sm" 
                            />
                          ) : (
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <Icon className="h-4 w-4 text-primary" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm">{getNotificationText(notification)}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                          </p>
                        </div>
                        {!notification.read && (
                          <div className="w-2 h-2 rounded-full bg-primary shrink-0 mt-2" />
                        )}
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center text-muted-foreground">
                  <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No notifications yet</p>
                </div>
              )}
            </ScrollArea>
          </PopoverContent>
        </Popover>
      </nav>

      <div className="flex items-center gap-2">
        <Button
          onClick={onCreatePost}
          size="sm"
          className="gap-1 hidden sm:flex"
          data-testid="button-create-post"
        >
          <Plus className="h-4 w-4" />
          Post
        </Button>
        <Button
          onClick={onCreatePost}
          size="icon"
          className="sm:hidden"
          data-testid="button-create-post-mobile"
        >
          <Plus className="h-4 w-4" />
        </Button>

        <ThemeToggle />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full" data-testid="button-profile-menu">
              <UserAvatar name={user.name} image={user.image} size="sm" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <Link href="/profile">
              <DropdownMenuItem data-testid="menu-item-profile">
                <UserAvatar name={user.name} size="sm" className="mr-2" />
                View Profile
              </DropdownMenuItem>
            </Link>
            <DropdownMenuSeparator />
            <DropdownMenuItem data-testid="menu-item-settings">Settings</DropdownMenuItem>
            <DropdownMenuItem data-testid="menu-item-logout" className="text-destructive">
              Log Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button variant="ghost" size="icon" className="md:hidden" data-testid="button-mobile-menu">
          <Menu className="h-5 w-5" />
        </Button>
      </div>
    </header>
  );
}
