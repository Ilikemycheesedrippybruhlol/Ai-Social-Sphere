import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { UserAvatar } from "./UserAvatar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Image, Video, Sparkles, X, Loader2, Link, Brain, Wand2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface CreatePostCardProps {
  currentUser?: {
    name: string;
    image?: string;
  };
  onSubmit?: (post: {
    content: string;
    mediaType?: "image" | "video";
    mediaUrl?: string;
    aiCaptioned?: boolean;
    aiModerated?: boolean;
  }) => void;
  isSubmitting?: boolean;
}

const toneOptions = [
  { value: "friendly", label: "Friendly" },
  { value: "professional", label: "Professional" },
  { value: "humorous", label: "Humorous" },
  { value: "inspirational", label: "Inspirational" },
  { value: "casual", label: "Casual" },
];

export function CreatePostCard({ currentUser, onSubmit, isSubmitting }: CreatePostCardProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [content, setContent] = useState("");
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<"image" | "video" | null>(null);
  const [mediaUrlInput, setMediaUrlInput] = useState("");
  const [showMediaInput, setShowMediaInput] = useState<"image" | "video" | null>(null);
  const [aiCaptioned, setAiCaptioned] = useState(false);
  const [aiModerated, setAiModerated] = useState(false);
  
  // AI Post Generation states
  const [showAIGenerator, setShowAIGenerator] = useState(false);
  const [aiTopic, setAiTopic] = useState("");
  const [aiTone, setAiTone] = useState("friendly");
  const [aiGenerated, setAiGenerated] = useState(false);

  const user = currentUser || { name: "Alex Johnson" };

  const generateCaptionMutation = useMutation({
    mutationFn: async (imageUrl: string) => {
      const res = await apiRequest("POST", "/api/ai/caption", { imageUrl });
      return res.json();
    },
    onSuccess: (data: { caption: string }) => {
      setContent((prev) => prev + (prev ? "\n\n" : "") + data.caption);
      setAiCaptioned(true);
    },
  });

  const generatePostMutation = useMutation({
    mutationFn: async ({ topic, tone }: { topic: string; tone: string }) => {
      const res = await apiRequest("POST", "/api/ai/generate-post", { topic, tone, includeHashtags: true });
      return res.json();
    },
    onSuccess: (data: { content: string; hashtags: string[]; provider: string }) => {
      setContent(data.content);
      setAiGenerated(true);
      setShowAIGenerator(false);
      setAiTopic("");
    },
  });

  const moderateContentMutation = useMutation({
    mutationFn: async (contentToCheck: string) => {
      const res = await apiRequest("POST", "/api/ai/moderate", { content: contentToCheck });
      return res.json();
    },
  });

  const handleShowMediaInput = (type: "image" | "video") => {
    setShowMediaInput(type);
    setMediaUrlInput("");
  };

  const handleAddMediaUrl = () => {
    if (!mediaUrlInput.trim()) return;
    setMediaPreview(mediaUrlInput.trim());
    setMediaType(showMediaInput);
    setShowMediaInput(null);
    setMediaUrlInput("");
  };

  const handleGenerateCaption = async () => {
    if (!mediaPreview) return;
    generateCaptionMutation.mutate(mediaPreview);
  };

  const handleGeneratePost = () => {
    if (!aiTopic.trim()) return;
    generatePostMutation.mutate({ topic: aiTopic, tone: aiTone });
  };

  const handleSubmit = async () => {
    if (!content.trim() && !mediaPreview) return;

    let isApproved = true;
    if (content.trim()) {
      try {
        const result = await moderateContentMutation.mutateAsync(content);
        isApproved = result.approved;
        if (isApproved) {
          setAiModerated(true);
        }
      } catch {
        console.log("Moderation check failed, proceeding without moderation");
      }
    }

    onSubmit?.({
      content,
      mediaType: mediaType || undefined,
      mediaUrl: mediaPreview || undefined,
      aiCaptioned: aiCaptioned || aiGenerated,
      aiModerated: aiModerated || isApproved,
    });
    
    setContent("");
    setMediaPreview(null);
    setMediaType(null);
    setMediaUrlInput("");
    setShowMediaInput(null);
    setAiCaptioned(false);
    setAiModerated(false);
    setAiGenerated(false);
    setIsDialogOpen(false);
  };

  const clearMedia = () => {
    setMediaPreview(null);
    setMediaType(null);
    setAiCaptioned(false);
    setShowMediaInput(null);
    setMediaUrlInput("");
  };

  const isGeneratingCaption = generateCaptionMutation.isPending;
  const isGeneratingPost = generatePostMutation.isPending;
  const isCheckingModeration = moderateContentMutation.isPending;

  return (
    <>
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <UserAvatar name={user.name} image={user.image} />
            <button
              onClick={() => setIsDialogOpen(true)}
              className="flex-1 text-left px-4 py-3 rounded-full bg-muted text-muted-foreground hover-elevate transition-colors"
              data-testid="button-whats-on-mind"
            >
              What's on your mind, {user.name.split(" ")[0]}?
            </button>
          </div>
          <div className="flex items-center gap-2 mt-3 pt-3 border-t">
            <Button
              variant="ghost"
              className="flex-1 gap-2"
              onClick={() => {
                setIsDialogOpen(true);
                handleShowMediaInput("image");
              }}
              data-testid="button-add-photo"
            >
              <Image className="h-5 w-5 text-green-600" />
              <span className="hidden sm:inline">Photo</span>
            </Button>
            <Button
              variant="ghost"
              className="flex-1 gap-2"
              onClick={() => {
                setIsDialogOpen(true);
                handleShowMediaInput("video");
              }}
              data-testid="button-add-video"
            >
              <Video className="h-5 w-5 text-red-500" />
              <span className="hidden sm:inline">Video</span>
            </Button>
            <Button
              variant="ghost"
              className="flex-1 gap-2"
              onClick={() => {
                setIsDialogOpen(true);
                setShowAIGenerator(true);
              }}
              data-testid="button-ai-write"
            >
              <Brain className="h-5 w-5 text-primary" />
              <span className="hidden sm:inline">Llama AI</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={(open) => {
        setIsDialogOpen(open);
        if (!open) {
          setShowAIGenerator(false);
          setAiTopic("");
        }
      }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              Create Post
              {aiGenerated && (
                <Badge variant="secondary" className="text-xs">
                  <Sparkles className="h-3 w-3 mr-1" />
                  AI Generated
                </Badge>
              )}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <UserAvatar name={user.name} image={user.image} />
              <div>
                <p className="font-semibold text-sm">{user.name}</p>
                <p className="text-xs text-muted-foreground">Public</p>
              </div>
            </div>

            {/* AI Post Generator */}
            {showAIGenerator && !content && (
              <div className="p-4 border rounded-lg bg-gradient-to-r from-primary/5 to-primary/10 space-y-4">
                <div className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-primary" />
                  <span className="font-medium">Ask Llama AI to write your post</span>
                </div>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="ai-topic" className="text-sm">What do you want to post about?</Label>
                    <Input
                      id="ai-topic"
                      placeholder="e.g., My morning coffee routine, weekend hiking trip, new project launch..."
                      value={aiTopic}
                      onChange={(e) => setAiTopic(e.target.value)}
                      className="mt-1"
                      data-testid="input-ai-topic"
                    />
                  </div>
                  <div>
                    <Label className="text-sm">Tone</Label>
                    <Select value={aiTone} onValueChange={setAiTone}>
                      <SelectTrigger className="mt-1" data-testid="select-ai-tone">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {toneOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleGeneratePost}
                      disabled={!aiTopic.trim() || isGeneratingPost}
                      className="flex-1"
                      data-testid="button-generate-post"
                    >
                      {isGeneratingPost ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Wand2 className="h-4 w-4 mr-2" />
                          Generate Post
                        </>
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={() => setShowAIGenerator(false)}
                      data-testid="button-cancel-ai"
                    >
                      Write myself
                    </Button>
                  </div>
                </div>
              </div>
            )}

            <Textarea
              placeholder={`What's on your mind, ${user.name.split(" ")[0]}?`}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-32 resize-none border-0 focus-visible:ring-0 text-base"
              data-testid="input-post-content"
            />

            {mediaPreview && (
              <div className="relative rounded-lg overflow-hidden">
                <Button
                  variant="secondary"
                  size="icon"
                  className="absolute top-2 right-2 z-10"
                  onClick={clearMedia}
                  data-testid="button-remove-media"
                >
                  <X className="h-4 w-4" />
                </Button>
                {mediaType === "video" ? (
                  <div className="aspect-video bg-muted flex items-center justify-center">
                    <Video className="h-12 w-12 text-muted-foreground" />
                    <span className="ml-2 text-muted-foreground">Video Preview</span>
                  </div>
                ) : (
                  <img
                    src={mediaPreview}
                    alt="Upload preview"
                    className="w-full max-h-64 object-cover rounded-lg"
                  />
                )}
                {mediaPreview && (
                  <Button
                    variant="secondary"
                    size="sm"
                    className="absolute bottom-2 left-2 gap-1"
                    onClick={handleGenerateCaption}
                    disabled={isGeneratingCaption}
                    data-testid="button-generate-caption"
                  >
                    {isGeneratingCaption ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Sparkles className="h-4 w-4" />
                    )}
                    Generate Caption
                  </Button>
                )}
              </div>
            )}

            {showMediaInput && !mediaPreview && (
              <div className="space-y-2 p-3 border rounded-lg">
                <Label htmlFor="media-url" className="text-sm font-medium">
                  Paste {showMediaInput === "image" ? "image" : "video"} URL
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="media-url"
                    placeholder={`https://example.com/${showMediaInput === "image" ? "photo.jpg" : "video.mp4"}`}
                    value={mediaUrlInput}
                    onChange={(e) => setMediaUrlInput(e.target.value)}
                    data-testid="input-media-url"
                  />
                  <Button
                    onClick={handleAddMediaUrl}
                    disabled={!mediaUrlInput.trim()}
                    data-testid="button-add-media-url"
                  >
                    <Link className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowMediaInput(null)}
                  data-testid="button-cancel-media"
                >
                  Cancel
                </Button>
              </div>
            )}

            <div className="flex items-center gap-2 p-3 border rounded-lg">
              <span className="text-sm font-medium flex-1">Add to your post</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleShowMediaInput("image")}
                disabled={!!mediaPreview}
                data-testid="button-dialog-photo"
              >
                <Image className="h-5 w-5 text-green-600" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleShowMediaInput("video")}
                disabled={!!mediaPreview}
                data-testid="button-dialog-video"
              >
                <Video className="h-5 w-5 text-red-500" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowAIGenerator(true)}
                disabled={!!content}
                data-testid="button-dialog-ai"
              >
                <Brain className="h-5 w-5 text-primary" />
              </Button>
            </div>
          </div>
          <DialogFooter>
            <Button
              className="w-full"
              onClick={handleSubmit}
              disabled={(!content.trim() && !mediaPreview) || isSubmitting || isCheckingModeration}
              data-testid="button-submit-post"
            >
              {isSubmitting || isCheckingModeration ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  {isCheckingModeration ? "Checking..." : "Posting..."}
                </>
              ) : (
                "Post"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
