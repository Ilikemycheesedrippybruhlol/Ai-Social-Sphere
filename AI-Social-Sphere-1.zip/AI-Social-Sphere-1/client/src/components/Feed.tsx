import { useQuery, useMutation } from "@tanstack/react-query";
import { CreatePostCard } from "./CreatePostCard";
import { PostCard } from "./PostCard";
import { Stories } from "./Stories";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import type { PostWithDetails } from "../../../server/storage";

interface FeedProps {
  currentUser?: {
    name: string;
    image?: string;
  };
}

export function Feed({ currentUser }: FeedProps) {
  const { data: posts, isLoading, error } = useQuery<PostWithDetails[]>({
    queryKey: ["/api/posts"],
  });

  const createPostMutation = useMutation({
    mutationFn: async (newPost: {
      content: string;
      mediaType?: "image" | "video";
      mediaUrl?: string;
      aiCaptioned?: boolean;
      aiModerated?: boolean;
    }) => {
      const res = await apiRequest("POST", "/api/posts", newPost);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const handleCreatePost = async (newPost: {
    content: string;
    mediaType?: "image" | "video";
    mediaUrl?: string;
    aiCaptioned?: boolean;
    aiModerated?: boolean;
  }) => {
    await createPostMutation.mutateAsync(newPost);
  };

  if (isLoading) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-4 flex justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-4 text-center text-muted-foreground">
        Failed to load posts. Please try again.
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-4">
      <Stories currentUser={currentUser} />
      <CreatePostCard 
        currentUser={currentUser} 
        onSubmit={handleCreatePost}
        isSubmitting={createPostMutation.isPending}
      />
      {posts?.filter((post) => !post.isHidden).map((post) => (
        <PostCard 
          key={post.id} 
          post={{
            id: post.id,
            authorId: post.authorId,
            author: {
              name: post.author.name,
              image: post.author.profileImage || undefined,
              username: post.author.username || undefined,
            },
            content: post.content,
            mediaUrl: post.mediaUrl || undefined,
            mediaType: post.mediaType as "image" | "video" | undefined,
            timestamp: new Date(post.createdAt),
            likes: post.likes,
            comments: post.comments.map(c => ({
              id: c.id,
              author: {
                name: c.author.name,
                image: c.author.profileImage || undefined,
              },
              content: c.content,
              timestamp: new Date(c.createdAt),
              likes: c.likes,
              isLiked: c.isLiked,
            })),
            isLiked: post.isLiked,
            isSaved: post.isSaved,
            isFavorited: post.isFavorited,
            isHidden: post.isHidden,
            aiCaptioned: post.aiCaptioned || false,
            aiModerated: post.aiModerated || false,
            reactions: post.reactions ? Object.entries(post.reactions.byType || {}).map(([type, count]) => ({
              type: type as any,
              count: count as number,
            })) : undefined,
            userReaction: post.userReaction,
            isEdited: post.isEdited ?? undefined,
            editedAt: post.editedAt ? new Date(post.editedAt) : undefined,
            originalPostId: post.originalPostId || undefined,
            originalPost: post.originalPost ? {
              id: post.originalPost.id,
              author: {
                name: post.originalPost.author.name,
                image: post.originalPost.author.profileImage || undefined,
              },
              content: post.originalPost.content,
              mediaUrl: post.originalPost.mediaUrl || undefined,
              mediaType: post.originalPost.mediaType as "image" | "video" | undefined,
              timestamp: new Date(post.originalPost.createdAt),
            } : undefined,
            shareCount: post.shareCount ?? undefined,
          }} 
        />
      ))}
    </div>
  );
}
