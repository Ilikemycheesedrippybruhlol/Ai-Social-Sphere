import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { UserAvatar } from "./UserAvatar";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Plus, X, ChevronLeft, ChevronRight } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { StoryWithDetails } from "../../../server/storage";

interface StoriesProps {
  currentUser?: {
    name: string;
    image?: string;
  };
}

export function Stories({ currentUser }: StoriesProps) {
  const [selectedStoryIndex, setSelectedStoryIndex] = useState<number | null>(null);
  const user = currentUser || { name: "You" };

  const { data: stories, isLoading } = useQuery<StoryWithDetails[]>({
    queryKey: ["/api/stories"],
  });

  const viewStoryMutation = useMutation({
    mutationFn: async (storyId: string) => {
      const res = await apiRequest("POST", `/api/stories/${storyId}/view`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stories"] });
    },
  });

  const handleStoryClick = (index: number) => {
    setSelectedStoryIndex(index);
    if (stories && stories[index]) {
      viewStoryMutation.mutate(stories[index].id);
    }
  };

  const handlePrevStory = () => {
    if (selectedStoryIndex !== null && selectedStoryIndex > 0) {
      const newIndex = selectedStoryIndex - 1;
      setSelectedStoryIndex(newIndex);
      if (stories && stories[newIndex]) {
        viewStoryMutation.mutate(stories[newIndex].id);
      }
    }
  };

  const handleNextStory = () => {
    if (selectedStoryIndex !== null && stories && selectedStoryIndex < stories.length - 1) {
      const newIndex = selectedStoryIndex + 1;
      setSelectedStoryIndex(newIndex);
      if (stories[newIndex]) {
        viewStoryMutation.mutate(stories[newIndex].id);
      }
    } else {
      setSelectedStoryIndex(null);
    }
  };

  const groupedStories = stories?.reduce((acc, story) => {
    const authorId = story.authorId;
    if (!acc[authorId]) {
      acc[authorId] = {
        author: story.author,
        stories: [],
        hasUnviewed: false,
      };
    }
    acc[authorId].stories.push(story);
    if (!story.viewed) {
      acc[authorId].hasUnviewed = true;
    }
    return acc;
  }, {} as Record<string, { author: typeof stories[0]["author"]; stories: typeof stories; hasUnviewed: boolean }>);

  const storyAuthors = groupedStories ? Object.values(groupedStories) : [];
  const currentStory = selectedStoryIndex !== null && stories ? stories[selectedStoryIndex] : null;

  if (isLoading) {
    return (
      <div className="flex gap-3 p-4 overflow-x-auto">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="flex flex-col items-center gap-2 animate-pulse">
            <div className="w-16 h-16 rounded-full bg-muted" />
            <div className="w-12 h-3 bg-muted rounded" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <>
      <ScrollArea className="w-full">
        <div className="flex gap-3 p-4">
          <button
            className="flex flex-col items-center gap-2 shrink-0"
            data-testid="button-create-story"
          >
            <div className="relative w-16 h-16 rounded-full bg-muted flex items-center justify-center border-2 border-dashed border-muted-foreground/50">
              <Plus className="h-6 w-6 text-muted-foreground" />
            </div>
            <span className="text-xs text-muted-foreground">Add Story</span>
          </button>

          {storyAuthors.map((group, groupIndex) => (
            <button
              key={group.author.id}
              className="flex flex-col items-center gap-2 shrink-0"
              onClick={() => {
                const storyIndex = stories?.findIndex(s => s.authorId === group.author.id) ?? 0;
                handleStoryClick(storyIndex);
              }}
              data-testid={`story-author-${group.author.id}`}
            >
              <div className={`p-0.5 rounded-full ${group.hasUnviewed ? 'bg-gradient-to-tr from-primary to-primary/60' : 'bg-muted'}`}>
                <div className="p-0.5 bg-background rounded-full">
                  <UserAvatar 
                    name={group.author.name} 
                    image={group.author.profileImage || undefined} 
                    size="lg" 
                  />
                </div>
              </div>
              <span className="text-xs truncate max-w-16">{group.author.name.split(" ")[0]}</span>
            </button>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>

      <Dialog open={selectedStoryIndex !== null} onOpenChange={() => setSelectedStoryIndex(null)}>
        <DialogContent className="max-w-md p-0 overflow-hidden bg-black">
          <DialogHeader className="absolute top-0 left-0 right-0 z-10 p-4 bg-gradient-to-b from-black/60 to-transparent">
            {currentStory && (
              <div className="flex items-center gap-3">
                <UserAvatar 
                  name={currentStory.author.name} 
                  image={currentStory.author.profileImage || undefined}
                  size="sm" 
                />
                <DialogTitle className="text-white text-sm font-medium">
                  {currentStory.author.name}
                </DialogTitle>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="ml-auto text-white"
                  onClick={() => setSelectedStoryIndex(null)}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
            )}
          </DialogHeader>

          {currentStory && (
            <div className="relative aspect-[9/16] bg-black flex items-center justify-center">
              {currentStory.mediaType === "video" ? (
                <video
                  src={currentStory.mediaUrl}
                  autoPlay
                  className="max-w-full max-h-full object-contain"
                  onEnded={handleNextStory}
                />
              ) : (
                <img
                  src={currentStory.mediaUrl}
                  alt="Story"
                  className="max-w-full max-h-full object-contain"
                />
              )}

              {currentStory.caption && (
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent">
                  <p className="text-white text-sm">{currentStory.caption}</p>
                </div>
              )}

              <button
                className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/30 text-white opacity-0 hover:opacity-100 transition-opacity disabled:hidden"
                onClick={handlePrevStory}
                disabled={selectedStoryIndex === 0}
                style={{ visibility: selectedStoryIndex === 0 ? 'hidden' : 'visible' }}
              >
                <ChevronLeft className="h-6 w-6" />
              </button>

              <button
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/30 text-white opacity-0 hover:opacity-100 transition-opacity"
                onClick={handleNextStory}
                style={{ visibility: stories && selectedStoryIndex === stories.length - 1 ? 'hidden' : 'visible' }}
              >
                <ChevronRight className="h-6 w-6" />
              </button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
