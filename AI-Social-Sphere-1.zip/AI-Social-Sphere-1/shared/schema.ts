import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  name: text("name").notNull(),
  bio: text("bio"),
  profileImage: text("profile_image"),
  coverImage: text("cover_image"),
  location: text("location"),
  website: text("website"),
  friendCount: integer("friend_count").default(0),
  followerCount: integer("follower_count").default(0),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const posts = pgTable("posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  authorId: varchar("author_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  mediaUrl: text("media_url"),
  mediaType: text("media_type"),
  aiCaptioned: boolean("ai_captioned").default(false),
  aiModerated: boolean("ai_moderated").default(false),
  isEdited: boolean("is_edited").default(false),
  editedAt: timestamp("edited_at"),
  originalPostId: varchar("original_post_id"),
  shareCount: integer("share_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPostSchema = createInsertSchema(posts).omit({ id: true, createdAt: true, isEdited: true, editedAt: true, shareCount: true });
export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;

export const postEdits = pgTable("post_edits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").notNull().references(() => posts.id),
  previousContent: text("previous_content").notNull(),
  previousMediaUrl: text("previous_media_url"),
  editedAt: timestamp("edited_at").defaultNow().notNull(),
});

export const insertPostEditSchema = createInsertSchema(postEdits).omit({ id: true, editedAt: true });
export type InsertPostEdit = z.infer<typeof insertPostEditSchema>;
export type PostEdit = typeof postEdits.$inferSelect;

export const postShares = pgTable("post_shares", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  originalPostId: varchar("original_post_id").notNull().references(() => posts.id),
  sharedPostId: varchar("shared_post_id").notNull().references(() => posts.id),
  sharerId: varchar("sharer_id").notNull().references(() => users.id),
  shareText: text("share_text"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPostShareSchema = createInsertSchema(postShares).omit({ id: true, createdAt: true });
export type InsertPostShare = z.infer<typeof insertPostShareSchema>;
export type PostShare = typeof postShares.$inferSelect;

export const savedPosts = pgTable("saved_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  postId: varchar("post_id").notNull().references(() => posts.id),
  savedAt: timestamp("saved_at").defaultNow().notNull(),
});

export const insertSavedPostSchema = createInsertSchema(savedPosts).omit({ id: true, savedAt: true });
export type InsertSavedPost = z.infer<typeof insertSavedPostSchema>;
export type SavedPost = typeof savedPosts.$inferSelect;

export const comments = pgTable("comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").notNull().references(() => posts.id),
  authorId: varchar("author_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCommentSchema = createInsertSchema(comments).omit({ id: true, createdAt: true });
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

export const likes = pgTable("likes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").notNull().references(() => posts.id),
  userId: varchar("user_id").notNull().references(() => users.id),
});

export const insertLikeSchema = createInsertSchema(likes).omit({ id: true });
export type InsertLike = z.infer<typeof insertLikeSchema>;
export type Like = typeof likes.$inferSelect;

export const commentLikes = pgTable("comment_likes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  commentId: varchar("comment_id").notNull().references(() => comments.id),
  userId: varchar("user_id").notNull().references(() => users.id),
});

export const insertCommentLikeSchema = createInsertSchema(commentLikes).omit({ id: true });
export type InsertCommentLike = z.infer<typeof insertCommentLikeSchema>;
export type CommentLike = typeof commentLikes.$inferSelect;

// Reaction types for Facebook-style reactions
export const reactionTypes = ["like", "love", "haha", "wow", "sad", "angry"] as const;
export type ReactionType = typeof reactionTypes[number];

export const reactions = pgTable("reactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").notNull().references(() => posts.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type").notNull().$type<ReactionType>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertReactionSchema = createInsertSchema(reactions).omit({ id: true, createdAt: true });
export type InsertReaction = z.infer<typeof insertReactionSchema>;
export type Reaction = typeof reactions.$inferSelect;

// Friendships for social connections
export const friendshipStatuses = ["pending", "accepted", "rejected"] as const;
export type FriendshipStatus = typeof friendshipStatuses[number];

export const friendships = pgTable("friendships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  requesterId: varchar("requester_id").notNull().references(() => users.id),
  addresseeId: varchar("addressee_id").notNull().references(() => users.id),
  status: text("status").notNull().$type<FriendshipStatus>().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  respondedAt: timestamp("responded_at"),
});

export const insertFriendshipSchema = createInsertSchema(friendships).omit({ id: true, createdAt: true, respondedAt: true });
export type InsertFriendship = z.infer<typeof insertFriendshipSchema>;
export type Friendship = typeof friendships.$inferSelect;

// Notifications
export const notificationTypes = ["like", "comment", "friend_request", "friend_accept", "mention", "ai_suggestion"] as const;
export type NotificationType = typeof notificationTypes[number];

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type").notNull().$type<NotificationType>(),
  actorId: varchar("actor_id").references(() => users.id),
  postId: varchar("post_id").references(() => posts.id),
  content: text("content"),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// Stories (temporary posts)
export const stories = pgTable("stories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  authorId: varchar("author_id").notNull().references(() => users.id),
  mediaUrl: text("media_url").notNull(),
  mediaType: text("media_type").notNull(),
  caption: text("caption"),
  viewCount: integer("view_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const insertStorySchema = createInsertSchema(stories).omit({ id: true, createdAt: true, viewCount: true });
export type InsertStory = z.infer<typeof insertStorySchema>;
export type Story = typeof stories.$inferSelect;

// Story views
export const storyViews = pgTable("story_views", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  storyId: varchar("story_id").notNull().references(() => stories.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  viewedAt: timestamp("viewed_at").defaultNow().notNull(),
});

export const insertStoryViewSchema = createInsertSchema(storyViews).omit({ id: true, viewedAt: true });
export type InsertStoryView = z.infer<typeof insertStoryViewSchema>;
export type StoryView = typeof storyViews.$inferSelect;

// Hidden posts (posts the user doesn't want to see in their feed)
export const hiddenPosts = pgTable("hidden_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  postId: varchar("post_id").notNull().references(() => posts.id),
  hiddenAt: timestamp("hidden_at").defaultNow().notNull(),
});

export const insertHiddenPostSchema = createInsertSchema(hiddenPosts).omit({ id: true, hiddenAt: true });
export type InsertHiddenPost = z.infer<typeof insertHiddenPostSchema>;
export type HiddenPost = typeof hiddenPosts.$inferSelect;

// Favorite posts (posts the user marked as favorites)
export const favoritePosts = pgTable("favorite_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  postId: varchar("post_id").notNull().references(() => posts.id),
  favoritedAt: timestamp("favorited_at").defaultNow().notNull(),
});

export const insertFavoritePostSchema = createInsertSchema(favoritePosts).omit({ id: true, favoritedAt: true });
export type InsertFavoritePost = z.infer<typeof insertFavoritePostSchema>;
export type FavoritePost = typeof favoritePosts.$inferSelect;

// AI Chat messages
export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  role: text("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({ id: true, createdAt: true });
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

// Shared DTO types for frontend use (matching API JSON responses)
export type CommentWithDetails = {
  id: string;
  postId: string;
  authorId: string;
  content: string;
  createdAt: string;
  author: User;
  likes: number;
  isLiked: boolean;
};

export type PostWithDetails = {
  id: string;
  authorId: string;
  content: string;
  mediaUrl: string | null;
  mediaType: string | null;
  aiCaptioned: boolean | null;
  aiModerated: boolean | null;
  isEdited: boolean | null;
  editedAt: string | null;
  originalPostId: string | null;
  shareCount: number | null;
  createdAt: string;
  author: User;
  comments: CommentWithDetails[];
  likes: number;
  isLiked: boolean;
  isSaved: boolean;
  reactions: {
    total: number;
    byType: { [key in ReactionType]?: number };
  };
  userReaction?: ReactionType | null;
};

export type FriendshipWithDetails = {
  id: string;
  requesterId: string;
  addresseeId: string;
  status: FriendshipStatus;
  createdAt: string;
  respondedAt: string | null;
  requester: User;
  addressee: User;
};
