import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPostSchema, insertCommentSchema, insertStorySchema, reactionTypes } from "@shared/schema";
import type { ReactionType, FriendshipStatus } from "@shared/schema";
import { z } from "zod";
import OpenAI from "openai";

const DEMO_USER_ID = "demo-user";

type AIProvider = "llama" | "openai";

function getActiveAIProvider(): AIProvider {
  if (process.env.TOGETHER_API_KEY) return "llama";
  if (process.env.OPENAI_API_KEY) return "openai";
  return "openai";
}

function getLlamaClient(): OpenAI | null {
  if (!process.env.TOGETHER_API_KEY) {
    return null;
  }
  return new OpenAI({ 
    apiKey: process.env.TOGETHER_API_KEY,
    baseURL: "https://api.together.xyz/v1"
  });
}

function getOpenAIClient(): OpenAI | null {
  if (!process.env.OPENAI_API_KEY) {
    return null;
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

function getAIClient(): { client: OpenAI | null; provider: AIProvider; model: string } {
  const llamaClient = getLlamaClient();
  if (llamaClient) {
    return { client: llamaClient, provider: "llama", model: "meta-llama/Llama-3.3-70B-Instruct-Turbo" };
  }
  const openaiClient = getOpenAIClient();
  if (openaiClient) {
    return { client: openaiClient, provider: "openai", model: "gpt-4o" };
  }
  return { client: null, provider: "openai", model: "gpt-4o" };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Get current user
  app.get("/api/me", async (req, res) => {
    try {
      const user = await storage.getUser(DEMO_USER_ID);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Get user by id
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Get user's posts
  app.get("/api/users/:id/posts", async (req, res) => {
    try {
      const posts = await storage.getPostsByUser(req.params.id, DEMO_USER_ID);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching user posts:", error);
      res.status(500).json({ message: "Failed to fetch user posts" });
    }
  });

  // Get user profile with posts and friendship status
  app.get("/api/users/:id/profile", async (req, res) => {
    try {
      const userId = req.params.id;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const posts = await storage.getPostsByUser(userId, DEMO_USER_ID);
      const friends = await storage.getFriends(DEMO_USER_ID);
      const pendingRequests = await storage.getFriendRequests(DEMO_USER_ID);
      
      const isFriend = friends.some(f => f.id === userId);
      const friendRequestSent = pendingRequests.some(
        r => r.addresseeId === userId || r.requesterId === userId
      );

      res.json({
        user,
        posts,
        isFriend,
        friendRequestSent,
      });
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  // Update user profile
  app.patch("/api/users/:id", async (req, res) => {
    try {
      const userId = req.params.id;
      
      if (userId !== DEMO_USER_ID) {
        return res.status(403).json({ message: "You can only update your own profile" });
      }
      
      const { name, bio, location, website, profileImage, coverImage } = req.body;
      const updatedUser = await storage.updateUser(userId, { 
        name, bio, location, website, profileImage, coverImage 
      });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // === HIDE POSTS ===

  // Toggle hide post
  app.post("/api/posts/:id/hide", async (req, res) => {
    try {
      const postId = req.params.id;
      const post = await storage.getPost(postId, DEMO_USER_ID);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const isHidden = await storage.isPostHidden(DEMO_USER_ID, postId);
      
      if (isHidden) {
        await storage.unhidePost(DEMO_USER_ID, postId);
        res.json({ hidden: false });
      } else {
        await storage.hidePost(DEMO_USER_ID, postId);
        res.json({ hidden: true });
      }
    } catch (error) {
      console.error("Error toggling hide post:", error);
      res.status(500).json({ message: "Failed to toggle hide post" });
    }
  });

  // Get hidden posts
  app.get("/api/hidden-posts", async (req, res) => {
    try {
      const hiddenPosts = await storage.getHiddenPosts(DEMO_USER_ID);
      res.json(hiddenPosts);
    } catch (error) {
      console.error("Error fetching hidden posts:", error);
      res.status(500).json({ message: "Failed to fetch hidden posts" });
    }
  });

  // === FAVORITE POSTS ===

  // Toggle favorite post
  app.post("/api/posts/:id/favorite", async (req, res) => {
    try {
      const postId = req.params.id;
      const post = await storage.getPost(postId, DEMO_USER_ID);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const isFavorited = await storage.isPostFavorited(DEMO_USER_ID, postId);
      
      if (isFavorited) {
        await storage.unfavoritePost(DEMO_USER_ID, postId);
        res.json({ favorited: false });
      } else {
        await storage.favoritePost(DEMO_USER_ID, postId);
        res.json({ favorited: true });
      }
    } catch (error) {
      console.error("Error toggling favorite post:", error);
      res.status(500).json({ message: "Failed to toggle favorite post" });
    }
  });

  // Get favorite posts
  app.get("/api/favorite-posts", async (req, res) => {
    try {
      const favoritePosts = await storage.getFavoritePosts(DEMO_USER_ID);
      res.json(favoritePosts);
    } catch (error) {
      console.error("Error fetching favorite posts:", error);
      res.status(500).json({ message: "Failed to fetch favorite posts" });
    }
  });

  // === AI CHAT ===

  // Get chat messages
  app.get("/api/chat/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages(DEMO_USER_ID);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // Send chat message and get AI response
  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!message || typeof message !== "string") {
        return res.status(400).json({ message: "Message is required" });
      }
      
      // Save user message
      await storage.saveChatMessage({
        userId: DEMO_USER_ID,
        role: "user",
        content: message,
      });
      
      const { client, model } = getAIClient();
      if (!client) {
        const errorMessage = "AI is not available. Please configure an API key.";
        await storage.saveChatMessage({
          userId: DEMO_USER_ID,
          role: "assistant",
          content: errorMessage,
        });
        return res.json({ response: errorMessage });
      }
      
      // Get recent conversation history for context
      const recentMessages = await storage.getChatMessages(DEMO_USER_ID);
      const conversationHistory = recentMessages.slice(-10).map(m => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      }));
      
      const response = await client.chat.completions.create({
        model,
        messages: [
          {
            role: "system",
            content: "You are a friendly and helpful AI assistant on a social media platform called SocialAI. Help users with their questions, provide advice, and engage in friendly conversation. Keep responses concise and helpful.",
          },
          ...conversationHistory,
        ],
        max_tokens: 500,
      });
      
      const aiResponse = response.choices[0]?.message?.content || "I'm sorry, I couldn't generate a response.";
      
      // Save AI response
      await storage.saveChatMessage({
        userId: DEMO_USER_ID,
        role: "assistant",
        content: aiResponse,
      });
      
      res.json({ response: aiResponse });
    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ message: "Failed to get AI response" });
    }
  });

  // Clear chat history
  app.delete("/api/chat/messages", async (req, res) => {
    try {
      await storage.clearChatHistory(DEMO_USER_ID);
      res.json({ success: true });
    } catch (error) {
      console.error("Error clearing chat history:", error);
      res.status(500).json({ message: "Failed to clear chat history" });
    }
  });

  // Get all posts
  app.get("/api/posts", async (req, res) => {
    try {
      const posts = await storage.getPosts(DEMO_USER_ID);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  // Get single post
  app.get("/api/posts/:id", async (req, res) => {
    try {
      const post = await storage.getPost(req.params.id, DEMO_USER_ID);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      res.json(post);
    } catch (error) {
      console.error("Error fetching post:", error);
      res.status(500).json({ message: "Failed to fetch post" });
    }
  });

  // Create post
  app.post("/api/posts", async (req, res) => {
    try {
      const validatedData = insertPostSchema.parse({
        ...req.body,
        authorId: DEMO_USER_ID,
      });
      const post = await storage.createPost(validatedData);
      const postWithDetails = await storage.getPost(post.id, DEMO_USER_ID);
      res.status(201).json(postWithDetails);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid post data", errors: error.errors });
      }
      console.error("Error creating post:", error);
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  // Update/Edit post
  app.patch("/api/posts/:id", async (req, res) => {
    try {
      const postId = req.params.id;
      const post = await storage.getPost(postId, DEMO_USER_ID);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      if (post.authorId !== DEMO_USER_ID) {
        return res.status(403).json({ message: "You can only edit your own posts" });
      }
      
      const { content, mediaUrl, mediaType } = req.body;
      const updatedPost = await storage.updatePost(postId, { content, mediaUrl, mediaType });
      const postWithDetails = await storage.getPost(postId, DEMO_USER_ID);
      
      res.json(postWithDetails);
    } catch (error) {
      console.error("Error updating post:", error);
      res.status(500).json({ message: "Failed to update post" });
    }
  });

  // Delete post
  app.delete("/api/posts/:id", async (req, res) => {
    try {
      const postId = req.params.id;
      const post = await storage.getPost(postId, DEMO_USER_ID);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      if (post.authorId !== DEMO_USER_ID) {
        return res.status(403).json({ message: "You can only delete your own posts" });
      }
      
      await storage.deletePost(postId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting post:", error);
      res.status(500).json({ message: "Failed to delete post" });
    }
  });

  // Share post
  app.post("/api/posts/:id/share", async (req, res) => {
    try {
      const originalPostId = req.params.id;
      const { shareText } = req.body;
      
      const originalPost = await storage.getPost(originalPostId, DEMO_USER_ID);
      if (!originalPost) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const sharedPost = await storage.sharePost(DEMO_USER_ID, originalPostId, shareText);
      const postWithDetails = await storage.getPost(sharedPost.id, DEMO_USER_ID);
      
      if (originalPost.authorId !== DEMO_USER_ID) {
        await storage.createNotification({
          userId: originalPost.authorId,
          type: "mention",
          actorId: DEMO_USER_ID,
          postId: sharedPost.id,
          content: "shared your post",
        });
      }
      
      res.status(201).json(postWithDetails);
    } catch (error) {
      console.error("Error sharing post:", error);
      res.status(500).json({ message: "Failed to share post" });
    }
  });

  // Get post edit history
  app.get("/api/posts/:id/edits", async (req, res) => {
    try {
      const edits = await storage.getPostEditHistory(req.params.id);
      res.json(edits);
    } catch (error) {
      console.error("Error fetching post edits:", error);
      res.status(500).json({ message: "Failed to fetch edit history" });
    }
  });

  // Save post
  app.post("/api/posts/:id/save", async (req, res) => {
    try {
      const postId = req.params.id;
      const post = await storage.getPost(postId, DEMO_USER_ID);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const isSaved = await storage.isPostSaved(DEMO_USER_ID, postId);
      
      if (isSaved) {
        await storage.unsavePost(DEMO_USER_ID, postId);
        res.json({ saved: false });
      } else {
        await storage.savePost(DEMO_USER_ID, postId);
        res.json({ saved: true });
      }
    } catch (error) {
      console.error("Error saving post:", error);
      res.status(500).json({ message: "Failed to save post" });
    }
  });

  // Get saved posts
  app.get("/api/saved-posts", async (req, res) => {
    try {
      const savedPosts = await storage.getSavedPosts(DEMO_USER_ID);
      res.json(savedPosts);
    } catch (error) {
      console.error("Error fetching saved posts:", error);
      res.status(500).json({ message: "Failed to fetch saved posts" });
    }
  });

  // Like/unlike post (legacy)
  app.post("/api/posts/:id/like", async (req, res) => {
    try {
      const postId = req.params.id;
      const post = await storage.getPost(postId, DEMO_USER_ID);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      let liked: boolean;
      if (post.isLiked) {
        await storage.unlikePost(DEMO_USER_ID, postId);
        await storage.removeReaction(DEMO_USER_ID, postId);
        liked = false;
      } else {
        await storage.likePost(DEMO_USER_ID, postId);
        liked = true;
      }

      const updatedPost = await storage.getPost(postId, DEMO_USER_ID);
      res.json({ liked, likes: updatedPost?.likes || 0 });
    } catch (error) {
      console.error("Error toggling like:", error);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  // Add reaction to post
  app.post("/api/posts/:id/react", async (req, res) => {
    try {
      const postId = req.params.id;
      const { type } = req.body;

      if (!type || !reactionTypes.includes(type)) {
        return res.status(400).json({ message: "Invalid reaction type" });
      }

      const post = await storage.getPost(postId, DEMO_USER_ID);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      await storage.addReaction(DEMO_USER_ID, postId, type as ReactionType);
      const updatedPost = await storage.getPost(postId, DEMO_USER_ID);
      
      res.json({ 
        reactions: updatedPost?.reactions,
        userReaction: type,
      });
    } catch (error) {
      console.error("Error adding reaction:", error);
      res.status(500).json({ message: "Failed to add reaction" });
    }
  });

  // Remove reaction from post
  app.delete("/api/posts/:id/react", async (req, res) => {
    try {
      const postId = req.params.id;
      await storage.removeReaction(DEMO_USER_ID, postId);
      const updatedPost = await storage.getPost(postId, DEMO_USER_ID);
      
      res.json({ 
        reactions: updatedPost?.reactions,
        userReaction: null,
      });
    } catch (error) {
      console.error("Error removing reaction:", error);
      res.status(500).json({ message: "Failed to remove reaction" });
    }
  });

  // Add comment to post
  app.post("/api/posts/:id/comments", async (req, res) => {
    try {
      const validatedData = insertCommentSchema.parse({
        ...req.body,
        postId: req.params.id,
        authorId: DEMO_USER_ID,
      });

      const post = await storage.getPost(req.params.id, DEMO_USER_ID);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      const comment = await storage.createComment(validatedData);
      const comments = await storage.getCommentsByPost(req.params.id, DEMO_USER_ID);
      const newComment = comments.find(c => c.id === comment.id);
      res.status(201).json(newComment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      }
      console.error("Error creating comment:", error);
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  // Like/unlike comment
  app.post("/api/comments/:id/like", async (req, res) => {
    try {
      const commentId = req.params.id;
      const comment = await storage.getComment(commentId, DEMO_USER_ID);
      
      if (!comment) {
        return res.status(404).json({ message: "Comment not found" });
      }

      let liked: boolean;
      if (comment.isLiked) {
        await storage.unlikeComment(DEMO_USER_ID, commentId);
        liked = false;
      } else {
        await storage.likeComment(DEMO_USER_ID, commentId);
        liked = true;
      }

      const updatedComment = await storage.getComment(commentId, DEMO_USER_ID);
      res.json({ liked, likes: updatedComment?.likes || 0 });
    } catch (error) {
      console.error("Error toggling comment like:", error);
      res.status(500).json({ message: "Failed to toggle comment like" });
    }
  });

  // === FRIENDSHIPS ===
  
  // Get friends list
  app.get("/api/friends", async (req, res) => {
    try {
      const friends = await storage.getFriends(DEMO_USER_ID);
      res.json(friends);
    } catch (error) {
      console.error("Error fetching friends:", error);
      res.status(500).json({ message: "Failed to fetch friends" });
    }
  });

  // Get friend requests
  app.get("/api/friends/requests", async (req, res) => {
    try {
      const requests = await storage.getFriendRequests(DEMO_USER_ID);
      res.json(requests);
    } catch (error) {
      console.error("Error fetching friend requests:", error);
      res.status(500).json({ message: "Failed to fetch friend requests" });
    }
  });

  // Get suggested friends
  app.get("/api/friends/suggestions", async (req, res) => {
    try {
      const suggestions = await storage.getSuggestedFriends(DEMO_USER_ID);
      res.json(suggestions);
    } catch (error) {
      console.error("Error fetching friend suggestions:", error);
      res.status(500).json({ message: "Failed to fetch friend suggestions" });
    }
  });

  // Send friend request
  app.post("/api/friends/request/:userId", async (req, res) => {
    try {
      const friendship = await storage.sendFriendRequest(DEMO_USER_ID, req.params.userId);
      res.status(201).json(friendship);
    } catch (error) {
      console.error("Error sending friend request:", error);
      res.status(500).json({ message: "Failed to send friend request" });
    }
  });

  // Respond to friend request
  app.post("/api/friends/respond/:friendshipId", async (req, res) => {
    try {
      const { status } = req.body;
      if (!status || !["accepted", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }

      const friendship = await storage.respondToFriendRequest(
        req.params.friendshipId,
        status as FriendshipStatus
      );

      if (!friendship) {
        return res.status(404).json({ message: "Friend request not found" });
      }

      res.json(friendship);
    } catch (error) {
      console.error("Error responding to friend request:", error);
      res.status(500).json({ message: "Failed to respond to friend request" });
    }
  });

  // === NOTIFICATIONS ===
  
  // Get notifications
  app.get("/api/notifications", async (req, res) => {
    try {
      const notifications = await storage.getNotifications(DEMO_USER_ID);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  // Get unread notification count
  app.get("/api/notifications/unread-count", async (req, res) => {
    try {
      const count = await storage.getUnreadNotificationCount(DEMO_USER_ID);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread count:", error);
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });

  // Mark notification as read
  app.post("/api/notifications/:id/read", async (req, res) => {
    try {
      const success = await storage.markNotificationRead(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Notification not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification read:", error);
      res.status(500).json({ message: "Failed to mark notification read" });
    }
  });

  // Mark all notifications as read
  app.post("/api/notifications/read-all", async (req, res) => {
    try {
      await storage.markAllNotificationsRead(DEMO_USER_ID);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking all notifications read:", error);
      res.status(500).json({ message: "Failed to mark all notifications read" });
    }
  });

  // === STORIES ===
  
  // Get all stories
  app.get("/api/stories", async (req, res) => {
    try {
      const stories = await storage.getStories(DEMO_USER_ID);
      res.json(stories);
    } catch (error) {
      console.error("Error fetching stories:", error);
      res.status(500).json({ message: "Failed to fetch stories" });
    }
  });

  // Create story
  app.post("/api/stories", async (req, res) => {
    try {
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
      const validatedData = insertStorySchema.parse({
        ...req.body,
        authorId: DEMO_USER_ID,
        expiresAt,
      });
      const story = await storage.createStory(validatedData);
      const storyWithDetails = await storage.getStory(story.id, DEMO_USER_ID);
      res.status(201).json(storyWithDetails);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid story data", errors: error.errors });
      }
      console.error("Error creating story:", error);
      res.status(500).json({ message: "Failed to create story" });
    }
  });

  // View story
  app.post("/api/stories/:id/view", async (req, res) => {
    try {
      await storage.viewStory(DEMO_USER_ID, req.params.id);
      const story = await storage.getStory(req.params.id, DEMO_USER_ID);
      res.json(story);
    } catch (error) {
      console.error("Error viewing story:", error);
      res.status(500).json({ message: "Failed to view story" });
    }
  });

  // === AI FEATURES ===

  // Seed demo data
  app.post("/api/seed", async (req, res) => {
    try {
      await storage.seedDemoData();
      res.json({ success: true, message: "Demo data seeded successfully" });
    } catch (error) {
      console.error("Error seeding data:", error);
      res.status(500).json({ message: "Failed to seed demo data" });
    }
  });

  // AI Caption Generation
  app.post("/api/ai/caption", async (req, res) => {
    try {
      const { imageUrl, context } = req.body;
      
      if (!imageUrl) {
        return res.status(400).json({ message: "Image URL is required" });
      }

      const { client, model } = getAIClient();
      if (!client) {
        return res.status(500).json({ message: "AI API key not configured (TOGETHER_API_KEY or OPENAI_API_KEY)" });
      }

      const response = await client.chat.completions.create({
        model,
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Generate a creative and engaging social media caption for this image. ${context ? `Context: ${context}` : ""} Keep it concise (1-2 sentences), friendly, and suitable for a social media post. Don't use hashtags unless specifically asked.`,
              },
              {
                type: "image_url",
                image_url: { url: imageUrl },
              },
            ],
          },
        ],
        max_tokens: 150,
      });

      const caption = response.choices[0]?.message?.content || "A beautiful moment captured in time.";
      res.json({ caption });
    } catch (error) {
      console.error("Error generating caption:", error);
      res.status(500).json({ message: "Failed to generate caption" });
    }
  });

  // AI Content Moderation
  app.post("/api/ai/moderate", async (req, res) => {
    try {
      const { content } = req.body;
      
      if (!content) {
        return res.status(400).json({ message: "Content is required" });
      }

      const { client, provider, model } = getAIClient();
      if (!client) {
        return res.status(500).json({ message: "AI API key not configured" });
      }

      if (provider === "openai") {
        const response = await client.moderations.create({
          input: content,
        });

        const result = response.results[0];
        const flagged = result?.flagged || false;
        const categories = result?.categories || {};
        
        res.json({ 
          approved: !flagged, 
          flagged,
          categories: Object.entries(categories)
            .filter(([_, value]) => value)
            .map(([key]) => key),
        });
      } else {
        const response = await client.chat.completions.create({
          model,
          messages: [
            {
              role: "system",
              content: "You are a content moderation assistant. Analyze the following text and respond with a JSON object containing: { \"flagged\": boolean, \"categories\": string[] }. Categories can include: harassment, hate, violence, sexual, self-harm. Only include categories that apply. Be strict but fair.",
            },
            {
              role: "user",
              content: `Analyze this content for moderation: "${content}"`,
            },
          ],
          max_tokens: 100,
        });

        try {
          const text = response.choices[0]?.message?.content || '{"flagged": false, "categories": []}';
          const parsed = JSON.parse(text.replace(/```json\n?|\n?```/g, ''));
          res.json({ 
            approved: !parsed.flagged, 
            flagged: parsed.flagged || false,
            categories: parsed.categories || [],
          });
        } catch {
          res.json({ approved: true, flagged: false, categories: [] });
        }
      }
    } catch (error) {
      console.error("Error moderating content:", error);
      res.status(500).json({ message: "Failed to moderate content" });
    }
  });

  // AI Smart Reply Suggestions
  app.post("/api/ai/smart-replies", async (req, res) => {
    try {
      const { postContent, commentContext } = req.body;
      
      if (!postContent) {
        return res.status(400).json({ message: "Post content is required" });
      }

      const { client, model } = getAIClient();
      if (!client) {
        return res.json({ 
          suggestions: [
            "Great post!",
            "Thanks for sharing!",
            "Love this!",
          ]
        });
      }

      const response = await client.chat.completions.create({
        model,
        messages: [
          {
            role: "system",
            content: "You are a helpful assistant that generates short, friendly social media comment suggestions. Generate exactly 3 comment suggestions, each on a new line. Keep them brief (under 10 words each), natural, and appropriate for social media.",
          },
          {
            role: "user",
            content: `Generate 3 comment suggestions for this post:\n\nPost: "${postContent}"${commentContext ? `\n\nExisting comments context: ${commentContext}` : ""}`,
          },
        ],
        max_tokens: 100,
      });

      const content = response.choices[0]?.message?.content || "";
      const suggestions = content.split("\n").filter(s => s.trim()).slice(0, 3);
      
      res.json({ suggestions: suggestions.length > 0 ? suggestions : ["Great post!", "Thanks for sharing!", "Love this!"] });
    } catch (error) {
      console.error("Error generating smart replies:", error);
      res.json({ 
        suggestions: ["Great post!", "Thanks for sharing!", "Love this!"]
      });
    }
  });

  // AI Content Ideas
  app.post("/api/ai/content-ideas", async (req, res) => {
    try {
      const { interests } = req.body;

      const { client, model } = getAIClient();
      if (!client) {
        return res.json({ 
          ideas: [
            "Share a photo from your recent adventure",
            "Tell us about your favorite hobby",
            "Post a throwback memory",
            "What are you grateful for today?",
            "Share something that made you smile",
          ]
        });
      }

      const response = await client.chat.completions.create({
        model,
        messages: [
          {
            role: "system",
            content: "You are a helpful assistant that generates creative social media post ideas. Generate exactly 5 post ideas, each on a new line. Keep them inspiring, varied, and appropriate for a social platform.",
          },
          {
            role: "user",
            content: `Generate 5 creative post ideas for a social media user.${interests ? ` Their interests include: ${interests}` : ""}`,
          },
        ],
        max_tokens: 200,
      });

      const content = response.choices[0]?.message?.content || "";
      const ideas = content.split("\n").filter(s => s.trim()).slice(0, 5);
      
      res.json({ 
        ideas: ideas.length > 0 ? ideas : [
          "Share a photo from your recent adventure",
          "Tell us about your favorite hobby",
          "Post a throwback memory",
          "What are you grateful for today?",
          "Share something that made you smile",
        ]
      });
    } catch (error) {
      console.error("Error generating content ideas:", error);
      res.json({ 
        ideas: [
          "Share a photo from your recent adventure",
          "Tell us about your favorite hobby",
          "Post a throwback memory",
        ]
      });
    }
  });

  // AI Generate Post
  app.post("/api/ai/generate-post", async (req, res) => {
    try {
      const { topic, tone, includeHashtags } = req.body;
      
      if (!topic) {
        return res.status(400).json({ message: "Topic is required" });
      }

      const { client, model, provider } = getAIClient();
      if (!client) {
        return res.json({ 
          content: `Here's a post about ${topic}: This is a placeholder post. Please configure TOGETHER_API_KEY or OPENAI_API_KEY for AI-generated content.`,
          hashtags: [],
          provider: "none"
        });
      }

      const toneInstruction = tone ? `The tone should be ${tone}.` : "The tone should be friendly and engaging.";
      const hashtagInstruction = includeHashtags !== false ? "Include 3-5 relevant hashtags at the end." : "Do not include hashtags.";

      const response = await client.chat.completions.create({
        model,
        messages: [
          {
            role: "system",
            content: `You are an expert social media content creator. Write engaging, authentic social media posts that resonate with audiences. Keep posts concise but impactful (under 280 characters for the main content, excluding hashtags). ${toneInstruction} ${hashtagInstruction}`,
          },
          {
            role: "user",
            content: `Write a social media post about: ${topic}`,
          },
        ],
        max_tokens: 200,
      });

      const content = response.choices[0]?.message?.content || `Check out this post about ${topic}!`;
      
      // Extract hashtags from the content
      const hashtagRegex = /#\w+/g;
      const hashtags = content.match(hashtagRegex) || [];
      
      res.json({ 
        content,
        hashtags,
        provider: provider === "llama" ? "Llama AI" : "AI"
      });
    } catch (error) {
      console.error("Error generating post:", error);
      res.json({ 
        content: "I'd love to help you create a post! Try describing what you want to share.",
        hashtags: [],
        provider: "none"
      });
    }
  });

  // AI Chat Assistant
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, context } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const { client, model } = getAIClient();
      if (!client) {
        return res.json({ 
          response: "AI assistant is currently unavailable. Please configure TOGETHER_API_KEY or OPENAI_API_KEY.",
        });
      }

      const response = await client.chat.completions.create({
        model,
        messages: [
          {
            role: "system",
            content: "You are a friendly AI assistant integrated into a social media platform called SocialAI. You help users with content creation, engagement tips, and general questions. Keep responses concise, helpful, and friendly. You can help with writing posts, suggesting hashtags, improving captions, and giving social media advice.",
          },
          ...(context ? [{ role: "user" as const, content: context }] : []),
          {
            role: "user",
            content: message,
          },
        ],
        max_tokens: 300,
      });

      const aiResponse = response.choices[0]?.message?.content || "I'm here to help! What would you like to know?";
      res.json({ response: aiResponse });
    } catch (error) {
      console.error("Error in AI chat:", error);
      res.json({ 
        response: "Sorry, I encountered an error. Please try again.",
      });
    }
  });

  return httpServer;
}
