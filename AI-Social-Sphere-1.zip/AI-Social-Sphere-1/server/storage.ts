import {
  type User, type InsertUser, users,
  type Post, type InsertPost, posts,
  type Comment, type InsertComment, comments,
  type Like, type InsertLike, likes,
  type CommentLike, type InsertCommentLike, commentLikes,
  type Reaction, type InsertReaction, type ReactionType, reactionTypes, reactions,
  type Friendship, type InsertFriendship, type FriendshipStatus, friendships,
  type Notification, type InsertNotification, type NotificationType, notifications,
  type Story, type InsertStory, stories,
  type StoryView, type InsertStoryView, storyViews,
  type PostEdit, type InsertPostEdit, postEdits,
  type PostShare, type InsertPostShare, postShares,
  type SavedPost, type InsertSavedPost, savedPosts,
  type HiddenPost, type InsertHiddenPost, hiddenPosts,
  type FavoritePost, type InsertFavoritePost, favoritePosts,
  type ChatMessage, type InsertChatMessage, chatMessages,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, asc, lt, sql, ne } from "drizzle-orm";

export interface PostWithDetails extends Post {
  author: User;
  likes: number;
  isLiked: boolean;
  comments: CommentWithDetails[];
  reactions: ReactionSummary;
  userReaction?: ReactionType;
  originalPost?: PostWithDetails;
  isSaved?: boolean;
  isFavorited?: boolean;
  isHidden?: boolean;
}

export interface ReactionSummary {
  total: number;
  byType: { [key in ReactionType]?: number };
}

export interface CommentWithDetails extends Comment {
  author: User;
  likes: number;
  isLiked: boolean;
}

export interface NotificationWithDetails extends Notification {
  actor?: User;
  post?: Post;
}

export interface StoryWithDetails extends Story {
  author: User;
  viewed: boolean;
}

export interface FriendshipWithDetails extends Friendship {
  requester: User;
  addressee: User;
}

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  getPosts(userId?: string): Promise<PostWithDetails[]>;
  getPost(id: string, userId?: string): Promise<PostWithDetails | undefined>;
  getPostsByUser(authorId: string, viewerId?: string): Promise<PostWithDetails[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: string, data: Partial<InsertPost>): Promise<Post | undefined>;
  deletePost(id: string): Promise<boolean>;
  
  getPostEditHistory(postId: string): Promise<PostEdit[]>;
  createPostEdit(edit: InsertPostEdit): Promise<PostEdit>;
  
  sharePost(sharerId: string, originalPostId: string, shareText?: string): Promise<Post>;
  getPostShares(postId: string): Promise<PostShare[]>;
  
  savePost(userId: string, postId: string): Promise<SavedPost>;
  unsavePost(userId: string, postId: string): Promise<boolean>;
  getSavedPosts(userId: string): Promise<PostWithDetails[]>;
  isPostSaved(userId: string, postId: string): Promise<boolean>;
  
  getComment(id: string, userId?: string): Promise<CommentWithDetails | undefined>;
  getCommentsByPost(postId: string, userId?: string): Promise<CommentWithDetails[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  deleteComment(id: string): Promise<boolean>;
  
  likePost(userId: string, postId: string): Promise<boolean>;
  unlikePost(userId: string, postId: string): Promise<boolean>;
  likeComment(userId: string, commentId: string): Promise<boolean>;
  unlikeComment(userId: string, commentId: string): Promise<boolean>;
  
  addReaction(userId: string, postId: string, type: ReactionType): Promise<Reaction>;
  removeReaction(userId: string, postId: string): Promise<boolean>;
  getReactionsByPost(postId: string): Promise<Reaction[]>;
  getUserReaction(userId: string, postId: string): Promise<Reaction | undefined>;
  
  sendFriendRequest(requesterId: string, addresseeId: string): Promise<Friendship>;
  respondToFriendRequest(friendshipId: string, status: FriendshipStatus): Promise<Friendship | undefined>;
  getFriendship(userId1: string, userId2: string): Promise<Friendship | undefined>;
  getFriends(userId: string): Promise<User[]>;
  getFriendRequests(userId: string): Promise<FriendshipWithDetails[]>;
  getSuggestedFriends(userId: string): Promise<User[]>;
  
  getNotifications(userId: string): Promise<NotificationWithDetails[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: string): Promise<boolean>;
  markAllNotificationsRead(userId: string): Promise<boolean>;
  getUnreadNotificationCount(userId: string): Promise<number>;
  
  getStories(userId: string): Promise<StoryWithDetails[]>;
  getStory(id: string, userId: string): Promise<StoryWithDetails | undefined>;
  createStory(story: InsertStory): Promise<Story>;
  viewStory(userId: string, storyId: string): Promise<boolean>;
  deleteExpiredStories(): Promise<number>;
  
  // Hidden posts
  hidePost(userId: string, postId: string): Promise<HiddenPost>;
  unhidePost(userId: string, postId: string): Promise<boolean>;
  isPostHidden(userId: string, postId: string): Promise<boolean>;
  getHiddenPosts(userId: string): Promise<PostWithDetails[]>;
  
  // Favorite posts
  favoritePost(userId: string, postId: string): Promise<FavoritePost>;
  unfavoritePost(userId: string, postId: string): Promise<boolean>;
  isPostFavorited(userId: string, postId: string): Promise<boolean>;
  getFavoritePosts(userId: string): Promise<PostWithDetails[]>;
  
  // AI Chat
  getChatMessages(userId: string): Promise<ChatMessage[]>;
  saveChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  clearChatHistory(userId: string): Promise<boolean>;
  
  seedDemoData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return user || undefined;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async getPosts(userId?: string): Promise<PostWithDetails[]> {
    const allPosts = await db.select().from(posts).orderBy(desc(posts.createdAt));
    return Promise.all(allPosts.map(post => this.enrichPost(post, userId)));
  }

  async getPost(id: string, userId?: string): Promise<PostWithDetails | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    if (!post) return undefined;
    return this.enrichPost(post, userId);
  }

  async getPostsByUser(authorId: string, viewerId?: string): Promise<PostWithDetails[]> {
    const userPosts = await db.select().from(posts)
      .where(eq(posts.authorId, authorId))
      .orderBy(desc(posts.createdAt));
    return Promise.all(userPosts.map(post => this.enrichPost(post, viewerId)));
  }

  private async enrichPost(post: Post, userId?: string): Promise<PostWithDetails> {
    const author = await this.getUser(post.authorId);
    const postReactions = await this.getReactionsByPost(post.id);
    const postComments = await this.getCommentsByPost(post.id, userId);
    const postLikesArr = await db.select().from(likes).where(eq(likes.postId, post.id));
    
    const reactionsByType: { [key in ReactionType]?: number } = {};
    postReactions.forEach(r => {
      reactionsByType[r.type] = (reactionsByType[r.type] || 0) + 1;
    });
    
    const userReaction = userId ? postReactions.find(r => r.userId === userId) : undefined;
    const isSaved = userId ? await this.isPostSaved(userId, post.id) : false;
    const isFavorited = userId ? await this.isPostFavorited(userId, post.id) : false;
    const isHidden = userId ? await this.isPostHidden(userId, post.id) : false;
    
    let originalPost: PostWithDetails | undefined;
    if (post.originalPostId) {
      const [original] = await db.select().from(posts).where(eq(posts.id, post.originalPostId));
      if (original) {
        originalPost = await this.enrichPost(original, userId);
      }
    }

    return {
      ...post,
      author: author!,
      likes: postLikesArr.length + postReactions.length,
      isLiked: userId ? (postLikesArr.some(l => l.userId === userId) || !!userReaction) : false,
      comments: postComments,
      reactions: {
        total: postReactions.length,
        byType: reactionsByType,
      },
      userReaction: userReaction?.type,
      originalPost,
      isSaved,
      isFavorited,
      isHidden,
    };
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const [post] = await db.insert(posts).values(insertPost).returning();
    return post;
  }

  async updatePost(id: string, data: Partial<InsertPost>): Promise<Post | undefined> {
    const [existing] = await db.select().from(posts).where(eq(posts.id, id));
    if (!existing) return undefined;
    
    await db.insert(postEdits).values({
      postId: id,
      previousContent: existing.content,
      previousMediaUrl: existing.mediaUrl,
    });
    
    const [updated] = await db.update(posts)
      .set({ ...data, isEdited: true, editedAt: new Date() })
      .where(eq(posts.id, id))
      .returning();
    return updated;
  }

  async deletePost(id: string): Promise<boolean> {
    await db.delete(comments).where(eq(comments.postId, id));
    await db.delete(likes).where(eq(likes.postId, id));
    await db.delete(reactions).where(eq(reactions.postId, id));
    await db.delete(postEdits).where(eq(postEdits.postId, id));
    await db.delete(savedPosts).where(eq(savedPosts.postId, id));
    const result = await db.delete(posts).where(eq(posts.id, id)).returning();
    return result.length > 0;
  }

  async getPostEditHistory(postId: string): Promise<PostEdit[]> {
    return db.select().from(postEdits)
      .where(eq(postEdits.postId, postId))
      .orderBy(desc(postEdits.editedAt));
  }

  async createPostEdit(edit: InsertPostEdit): Promise<PostEdit> {
    const [postEdit] = await db.insert(postEdits).values(edit).returning();
    return postEdit;
  }

  async sharePost(sharerId: string, originalPostId: string, shareText?: string): Promise<Post> {
    const [original] = await db.select().from(posts).where(eq(posts.id, originalPostId));
    if (!original) throw new Error("Original post not found");
    
    const [sharedPost] = await db.insert(posts).values({
      authorId: sharerId,
      content: shareText || "",
      originalPostId: originalPostId,
      aiCaptioned: false,
      aiModerated: false,
    }).returning();
    
    await db.insert(postShares).values({
      originalPostId,
      sharedPostId: sharedPost.id,
      sharerId,
      shareText,
    });
    
    await db.update(posts)
      .set({ shareCount: sql`${posts.shareCount} + 1` })
      .where(eq(posts.id, originalPostId));
    
    return sharedPost;
  }

  async getPostShares(postId: string): Promise<PostShare[]> {
    return db.select().from(postShares).where(eq(postShares.originalPostId, postId));
  }

  async savePost(userId: string, postId: string): Promise<SavedPost> {
    const [saved] = await db.insert(savedPosts).values({ userId, postId }).returning();
    return saved;
  }

  async unsavePost(userId: string, postId: string): Promise<boolean> {
    const result = await db.delete(savedPosts)
      .where(and(eq(savedPosts.userId, userId), eq(savedPosts.postId, postId)))
      .returning();
    return result.length > 0;
  }

  async getSavedPosts(userId: string): Promise<PostWithDetails[]> {
    const saved = await db.select().from(savedPosts)
      .where(eq(savedPosts.userId, userId))
      .orderBy(desc(savedPosts.savedAt));
    
    const postsWithDetails = await Promise.all(
      saved.map(async (s) => {
        const [post] = await db.select().from(posts).where(eq(posts.id, s.postId));
        if (!post) return null;
        return this.enrichPost(post, userId);
      })
    );
    
    return postsWithDetails.filter((p): p is PostWithDetails => p !== null);
  }

  async isPostSaved(userId: string, postId: string): Promise<boolean> {
    const [saved] = await db.select().from(savedPosts)
      .where(and(eq(savedPosts.userId, userId), eq(savedPosts.postId, postId)));
    return !!saved;
  }

  async getComment(id: string, userId?: string): Promise<CommentWithDetails | undefined> {
    const [comment] = await db.select().from(comments).where(eq(comments.id, id));
    if (!comment) return undefined;
    
    const author = await this.getUser(comment.authorId);
    const commentLikesArr = await db.select().from(commentLikes).where(eq(commentLikes.commentId, id));
    
    return {
      ...comment,
      author: author!,
      likes: commentLikesArr.length,
      isLiked: userId ? commentLikesArr.some(l => l.userId === userId) : false,
    };
  }

  async getCommentsByPost(postId: string, userId?: string): Promise<CommentWithDetails[]> {
    const postComments = await db.select().from(comments)
      .where(eq(comments.postId, postId))
      .orderBy(asc(comments.createdAt));
    
    return Promise.all(postComments.map(async (comment) => {
      const author = await this.getUser(comment.authorId);
      const commentLikesArr = await db.select().from(commentLikes).where(eq(commentLikes.commentId, comment.id));
      
      return {
        ...comment,
        author: author!,
        likes: commentLikesArr.length,
        isLiked: userId ? commentLikesArr.some(l => l.userId === userId) : false,
      };
    }));
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const [comment] = await db.insert(comments).values(insertComment).returning();
    return comment;
  }

  async deleteComment(id: string): Promise<boolean> {
    await db.delete(commentLikes).where(eq(commentLikes.commentId, id));
    const result = await db.delete(comments).where(eq(comments.id, id)).returning();
    return result.length > 0;
  }

  async likePost(userId: string, postId: string): Promise<boolean> {
    const [existing] = await db.select().from(likes)
      .where(and(eq(likes.userId, userId), eq(likes.postId, postId)));
    if (existing) return false;
    
    await db.insert(likes).values({ userId, postId });
    return true;
  }

  async unlikePost(userId: string, postId: string): Promise<boolean> {
    const result = await db.delete(likes)
      .where(and(eq(likes.userId, userId), eq(likes.postId, postId)))
      .returning();
    return result.length > 0;
  }

  async likeComment(userId: string, commentId: string): Promise<boolean> {
    const [existing] = await db.select().from(commentLikes)
      .where(and(eq(commentLikes.userId, userId), eq(commentLikes.commentId, commentId)));
    if (existing) return false;
    
    await db.insert(commentLikes).values({ userId, commentId });
    return true;
  }

  async unlikeComment(userId: string, commentId: string): Promise<boolean> {
    const result = await db.delete(commentLikes)
      .where(and(eq(commentLikes.userId, userId), eq(commentLikes.commentId, commentId)))
      .returning();
    return result.length > 0;
  }

  async addReaction(userId: string, postId: string, type: ReactionType): Promise<Reaction> {
    await this.removeReaction(userId, postId);
    const [reaction] = await db.insert(reactions).values({ userId, postId, type }).returning();
    return reaction;
  }

  async removeReaction(userId: string, postId: string): Promise<boolean> {
    const result = await db.delete(reactions)
      .where(and(eq(reactions.userId, userId), eq(reactions.postId, postId)))
      .returning();
    return result.length > 0;
  }

  async getReactionsByPost(postId: string): Promise<Reaction[]> {
    return db.select().from(reactions).where(eq(reactions.postId, postId));
  }

  async getUserReaction(userId: string, postId: string): Promise<Reaction | undefined> {
    const [reaction] = await db.select().from(reactions)
      .where(and(eq(reactions.userId, userId), eq(reactions.postId, postId)));
    return reaction || undefined;
  }

  async sendFriendRequest(requesterId: string, addresseeId: string): Promise<Friendship> {
    const existing = await this.getFriendship(requesterId, addresseeId);
    if (existing) throw new Error("Friendship already exists");
    
    const [friendship] = await db.insert(friendships)
      .values({ requesterId, addresseeId, status: "pending" })
      .returning();
    return friendship;
  }

  async respondToFriendRequest(friendshipId: string, status: FriendshipStatus): Promise<Friendship | undefined> {
    const [updated] = await db.update(friendships)
      .set({ status, respondedAt: new Date() })
      .where(eq(friendships.id, friendshipId))
      .returning();
    return updated || undefined;
  }

  async getFriendship(userId1: string, userId2: string): Promise<Friendship | undefined> {
    const [friendship] = await db.select().from(friendships)
      .where(or(
        and(eq(friendships.requesterId, userId1), eq(friendships.addresseeId, userId2)),
        and(eq(friendships.requesterId, userId2), eq(friendships.addresseeId, userId1))
      ));
    return friendship || undefined;
  }

  async getFriends(userId: string): Promise<User[]> {
    const acceptedFriendships = await db.select().from(friendships)
      .where(and(
        eq(friendships.status, "accepted"),
        or(eq(friendships.requesterId, userId), eq(friendships.addresseeId, userId))
      ));
    
    const friendIds = acceptedFriendships.map(f => 
      f.requesterId === userId ? f.addresseeId : f.requesterId
    );
    
    if (friendIds.length === 0) return [];
    
    const friends = await Promise.all(friendIds.map(id => this.getUser(id)));
    return friends.filter((u): u is User => u !== undefined);
  }

  async getFriendRequests(userId: string): Promise<FriendshipWithDetails[]> {
    const pendingRequests = await db.select().from(friendships)
      .where(and(eq(friendships.addresseeId, userId), eq(friendships.status, "pending")));
    
    return Promise.all(pendingRequests.map(async (f) => {
      const requester = await this.getUser(f.requesterId);
      const addressee = await this.getUser(f.addresseeId);
      return { ...f, requester: requester!, addressee: addressee! };
    }));
  }

  async getSuggestedFriends(userId: string): Promise<User[]> {
    const allUsers = await this.getAllUsers();
    const friends = await this.getFriends(userId);
    const friendIds = new Set(friends.map(f => f.id));
    friendIds.add(userId);
    
    return allUsers
      .filter(u => !friendIds.has(u.id))
      .slice(0, 5);
  }

  async getNotifications(userId: string): Promise<NotificationWithDetails[]> {
    const userNotifications = await db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
    
    return Promise.all(userNotifications.map(async (n) => {
      const actor = n.actorId ? await this.getUser(n.actorId) : undefined;
      const post = n.postId ? (await db.select().from(posts).where(eq(posts.id, n.postId)))[0] : undefined;
      return { ...n, actor, post };
    }));
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const [notification] = await db.insert(notifications).values({
      ...insertNotification,
      type: insertNotification.type as NotificationType,
    }).returning();
    return notification;
  }

  async markNotificationRead(id: string): Promise<boolean> {
    const result = await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id))
      .returning();
    return result.length > 0;
  }

  async markAllNotificationsRead(userId: string): Promise<boolean> {
    await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.userId, userId));
    return true;
  }

  async getUnreadNotificationCount(userId: string): Promise<number> {
    const unread = await db.select().from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.read, false)));
    return unread.length;
  }

  async getStories(userId: string): Promise<StoryWithDetails[]> {
    const now = new Date();
    const activeStories = await db.select().from(stories)
      .where(sql`${stories.expiresAt} > ${now}`)
      .orderBy(desc(stories.createdAt));
    
    return Promise.all(activeStories.map(async (story) => {
      const author = await this.getUser(story.authorId);
      const [view] = await db.select().from(storyViews)
        .where(and(eq(storyViews.storyId, story.id), eq(storyViews.userId, userId)));
      
      return { ...story, author: author!, viewed: !!view };
    }));
  }

  async getStory(id: string, userId: string): Promise<StoryWithDetails | undefined> {
    const [story] = await db.select().from(stories).where(eq(stories.id, id));
    if (!story) return undefined;
    
    const author = await this.getUser(story.authorId);
    const [view] = await db.select().from(storyViews)
      .where(and(eq(storyViews.storyId, id), eq(storyViews.userId, userId)));
    
    return { ...story, author: author!, viewed: !!view };
  }

  async createStory(insertStory: InsertStory): Promise<Story> {
    const [story] = await db.insert(stories).values(insertStory).returning();
    return story;
  }

  async viewStory(userId: string, storyId: string): Promise<boolean> {
    const [existing] = await db.select().from(storyViews)
      .where(and(eq(storyViews.userId, userId), eq(storyViews.storyId, storyId)));
    
    if (existing) return false;
    
    await db.insert(storyViews).values({ userId, storyId });
    await db.update(stories)
      .set({ viewCount: sql`${stories.viewCount} + 1` })
      .where(eq(stories.id, storyId));
    
    return true;
  }

  async deleteExpiredStories(): Promise<number> {
    const now = new Date();
    const expired = await db.delete(stories)
      .where(lt(stories.expiresAt, now))
      .returning();
    return expired.length;
  }

  // Hidden posts
  async hidePost(userId: string, postId: string): Promise<HiddenPost> {
    const [hidden] = await db.insert(hiddenPosts).values({ userId, postId }).returning();
    return hidden;
  }

  async unhidePost(userId: string, postId: string): Promise<boolean> {
    const result = await db.delete(hiddenPosts)
      .where(and(eq(hiddenPosts.userId, userId), eq(hiddenPosts.postId, postId)))
      .returning();
    return result.length > 0;
  }

  async isPostHidden(userId: string, postId: string): Promise<boolean> {
    const [hidden] = await db.select().from(hiddenPosts)
      .where(and(eq(hiddenPosts.userId, userId), eq(hiddenPosts.postId, postId)));
    return !!hidden;
  }

  async getHiddenPosts(userId: string): Promise<PostWithDetails[]> {
    const hidden = await db.select().from(hiddenPosts)
      .where(eq(hiddenPosts.userId, userId))
      .orderBy(desc(hiddenPosts.hiddenAt));
    
    const postIds = hidden.map(h => h.postId);
    const allPosts = await Promise.all(postIds.map(id => this.getPost(id, userId)));
    return allPosts.filter((p): p is PostWithDetails => p !== undefined);
  }

  // Favorite posts
  async favoritePost(userId: string, postId: string): Promise<FavoritePost> {
    const [favorite] = await db.insert(favoritePosts).values({ userId, postId }).returning();
    return favorite;
  }

  async unfavoritePost(userId: string, postId: string): Promise<boolean> {
    const result = await db.delete(favoritePosts)
      .where(and(eq(favoritePosts.userId, userId), eq(favoritePosts.postId, postId)))
      .returning();
    return result.length > 0;
  }

  async isPostFavorited(userId: string, postId: string): Promise<boolean> {
    const [favorite] = await db.select().from(favoritePosts)
      .where(and(eq(favoritePosts.userId, userId), eq(favoritePosts.postId, postId)));
    return !!favorite;
  }

  async getFavoritePosts(userId: string): Promise<PostWithDetails[]> {
    const favorites = await db.select().from(favoritePosts)
      .where(eq(favoritePosts.userId, userId))
      .orderBy(desc(favoritePosts.favoritedAt));
    
    const postIds = favorites.map(f => f.postId);
    const allPosts = await Promise.all(postIds.map(id => this.getPost(id, userId)));
    return allPosts.filter((p): p is PostWithDetails => p !== undefined);
  }

  // AI Chat
  async getChatMessages(userId: string): Promise<ChatMessage[]> {
    return db.select().from(chatMessages)
      .where(eq(chatMessages.userId, userId))
      .orderBy(asc(chatMessages.createdAt));
  }

  async saveChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [chatMessage] = await db.insert(chatMessages).values(message).returning();
    return chatMessage;
  }

  async clearChatHistory(userId: string): Promise<boolean> {
    const result = await db.delete(chatMessages)
      .where(eq(chatMessages.userId, userId))
      .returning();
    return result.length >= 0;
  }

  async seedDemoData(): Promise<void> {
    const existingUser = await this.getUser("demo-user");
    if (existingUser) return;

    const demoUser: InsertUser & { id?: string } = {
      username: "alex",
      name: "Alex Johnson",
      bio: "Tech enthusiast and nature lover. Always exploring new ideas.",
      profileImage: null,
      coverImage: null,
      location: "San Francisco, CA",
      website: "https://alexj.dev",
      friendCount: 142,
      followerCount: 1024,
    };
    
    await db.insert(users).values({ ...demoUser, id: "demo-user" });
    
    const sampleUsers = [
      { id: "user-1", username: "jessica", name: "Jessica Williams", bio: "Photographer & Visual Storyteller", profileImage: null, coverImage: null, location: "New York, NY", website: null, friendCount: 89, followerCount: 534 },
      { id: "user-2", username: "david", name: "David Chen", bio: "Runner, Developer, Coffee Lover", profileImage: null, coverImage: null, location: "Seattle, WA", website: null, friendCount: 156, followerCount: 312 },
      { id: "user-3", username: "maria", name: "Maria Garcia", bio: "Food blogger and recipe creator", profileImage: null, coverImage: null, location: "Austin, TX", website: "https://mariacooks.com", friendCount: 234, followerCount: 2100 },
      { id: "user-4", username: "james", name: "James Wilson", bio: "Music producer and DJ", profileImage: null, coverImage: null, location: "Los Angeles, CA", website: null, friendCount: 78, followerCount: 890 },
      { id: "user-5", username: "sarah", name: "Sarah Miller", bio: "Yoga instructor and wellness coach", profileImage: null, coverImage: null, location: "Denver, CO", website: null, friendCount: 123, followerCount: 456 },
    ];
    
    for (const user of sampleUsers) {
      await db.insert(users).values(user);
    }
    
    const samplePosts = [
      { id: "post-1", authorId: "user-1", content: "Just captured this incredible sunset during my evening hike! Nature never fails to amaze me. The colors were absolutely breathtaking.", mediaUrl: "https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=800", mediaType: "image", aiCaptioned: true, aiModerated: true },
      { id: "post-2", authorId: "user-2", content: "Excited to share that I just completed my first marathon! 26.2 miles of pure determination. Thanks to everyone who supported me along the way!", mediaUrl: null, mediaType: null, aiCaptioned: false, aiModerated: true },
      { id: "post-3", authorId: "user-3", content: "Finally tried that new Italian restaurant downtown. The homemade pasta was absolutely divine! Highly recommend the truffle carbonara.", mediaUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800", mediaType: "image", aiCaptioned: true, aiModerated: false },
      { id: "post-4", authorId: "user-4", content: "New track dropping next week! Been working on this one for months. Cannot wait to share it with you all.", mediaUrl: null, mediaType: null, aiCaptioned: false, aiModerated: true },
      { id: "post-5", authorId: "user-5", content: "Morning yoga session with this amazing view. Start your day with intention and gratitude. Namaste.", mediaUrl: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800", mediaType: "image", aiCaptioned: true, aiModerated: true },
    ];
    
    for (const post of samplePosts) {
      await db.insert(posts).values(post);
    }
    
    const sampleComments = [
      { id: "comment-1", postId: "post-1", authorId: "user-2", content: "This is absolutely beautiful! Where was this taken?" },
      { id: "comment-2", postId: "post-1", authorId: "demo-user", content: "Stunning shot! The colors are incredible." },
      { id: "comment-3", postId: "post-2", authorId: "user-1", content: "Congratulations! That's an amazing achievement!" },
      { id: "comment-4", postId: "post-3", authorId: "user-5", content: "I need to try this place! Looks delicious." },
    ];
    
    for (const comment of sampleComments) {
      await db.insert(comments).values(comment);
    }
    
    const sampleReactions = [
      { id: "reaction-1", postId: "post-1", userId: "demo-user", type: "love" as ReactionType },
      { id: "reaction-2", postId: "post-1", userId: "user-2", type: "like" as ReactionType },
      { id: "reaction-3", postId: "post-1", userId: "user-3", type: "wow" as ReactionType },
      { id: "reaction-4", postId: "post-2", userId: "demo-user", type: "like" as ReactionType },
      { id: "reaction-5", postId: "post-2", userId: "user-1", type: "love" as ReactionType },
    ];
    
    for (const reaction of sampleReactions) {
      await db.insert(reactions).values(reaction);
    }
    
    const sampleFriendships = [
      { id: "friend-1", requesterId: "demo-user", addresseeId: "user-1", status: "accepted" as FriendshipStatus },
      { id: "friend-2", requesterId: "user-2", addresseeId: "demo-user", status: "accepted" as FriendshipStatus },
      { id: "friend-3", requesterId: "user-4", addresseeId: "demo-user", status: "pending" as FriendshipStatus },
    ];
    
    for (const friendship of sampleFriendships) {
      await db.insert(friendships).values(friendship);
    }
    
    const sampleNotifications = [
      { id: "notif-1", userId: "demo-user", type: "friend_request" as NotificationType, actorId: "user-4", postId: null, content: null, read: false },
      { id: "notif-2", userId: "demo-user", type: "like" as NotificationType, actorId: "user-2", postId: "post-1", content: null, read: false },
    ];
    
    for (const notification of sampleNotifications) {
      await db.insert(notifications).values(notification);
    }
    
    const now = new Date();
    const sampleStories = [
      { id: "story-1", authorId: "user-1", mediaUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400", mediaType: "image", caption: "Good morning!", expiresAt: new Date(now.getTime() + 3600000 * 20) },
      { id: "story-2", authorId: "user-2", mediaUrl: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400", mediaType: "image", caption: "Training day!", expiresAt: new Date(now.getTime() + 3600000 * 22) },
      { id: "story-3", authorId: "user-3", mediaUrl: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400", mediaType: "image", caption: "Cooking something special", expiresAt: new Date(now.getTime() + 3600000 * 23) },
    ];
    
    for (const story of sampleStories) {
      await db.insert(stories).values(story);
    }
  }
}

export const storage = new DatabaseStorage();
